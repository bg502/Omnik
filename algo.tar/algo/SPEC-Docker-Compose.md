# SPEC: Complete Docker Compose Configuration
## Full System Deployment Specification

### Document Information
- Type: Docker Compose Specification
- Version: 1.0.0
- Environment: Production
- Network: External nginx-proxy integration

---

## Complete docker-compose.yml

```yaml
version: '3.8'

services:
  # =============================================================================
  # CORE SERVICES
  # =============================================================================
  
  # API Gateway - Main entry point for all HTTP requests
  api-gateway:
    build:
      context: ./services/api-gateway
      dockerfile: Dockerfile
    container_name: defi-api-gateway
    environment:
      # Service Configuration
      - SERVICE_NAME=api-gateway
      - PORT=8080
      - LOG_LEVEL=${LOG_LEVEL:-info}
      
      # Database
      - DATABASE_URL=postgres://defi:${DB_PASSWORD:-secure_password}@postgres:5432/defi_portfolio?sslmode=disable
      - REDIS_URL=redis://redis:6379/0
      
      # Nginx Proxy Integration (REQUIRED FOR YOUR SETUP)
      - VIRTUAL_HOST=${API_DOMAIN:-api.defi.yourdomain.com}
      - VIRTUAL_PORT=8080
      - LETSENCRYPT_HOST=${API_DOMAIN:-api.defi.yourdomain.com}
      - LETSENCRYPT_EMAIL=${ADMIN_EMAIL:-admin@yourdomain.com}
      
      # Security
      - JWT_SECRET=${JWT_SECRET:-your_jwt_secret_key_here}
      - API_RATE_LIMIT=100
      - CORS_ORIGINS=${CORS_ORIGINS:-https://defi.yourdomain.com}
      
      # Service Discovery
      - ORCHESTRATOR_URL=http://orchestrator:8081
      - EVALUATION_URL=http://evaluation-engine:8082
      - AGGREGATOR_URL=http://data-aggregator:8083
      - MONITORING_URL=http://monitoring:8084
      - REBALANCER_URL=http://rebalancer:8085
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./services/api-gateway/config:/app/config:ro
    networks:
      - defi-network
      - proxy  # External network for nginx-proxy
    ports:
      - "8080:8080"
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '1.0'
        reservations:
          memory: 256M
          cpus: '0.5'
    labels:
      - "com.defi.service=api-gateway"
      - "com.defi.tier=edge"

  # =============================================================================
  # Orchestrator Service - Workflow Coordination
  # =============================================================================
  orchestrator:
    build:
      context: ./services/orchestrator
      dockerfile: Dockerfile
    container_name: defi-orchestrator
    environment:
      - SERVICE_NAME=orchestrator
      - PORT=8081
      - LOG_LEVEL=${LOG_LEVEL:-info}
      - DATABASE_URL=postgres://defi:${DB_PASSWORD:-secure_password}@postgres:5432/defi_portfolio?sslmode=disable
      - REDIS_URL=redis://redis:6379/0
      - METRICS_ENABLED=true
      - METRICS_PORT=9091
      
      # Workflow Configuration
      - MAX_CONCURRENT_WORKFLOWS=50
      - DEFAULT_TASK_TIMEOUT=30
      - MAX_TASK_RETRIES=3
      - CIRCUIT_BREAKER_THRESHOLD=5
      - CIRCUIT_BREAKER_TIMEOUT=60
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./services/orchestrator/config:/app/config:ro
    networks:
      - defi-network
    ports:
      - "8081:8081"  # API port
      - "9091:9091"  # Metrics port
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:8081/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '1.0'
        reservations:
          memory: 256M
          cpus: '0.5'

  # =============================================================================
  # Evaluation Engine - Strategy Scoring (Multiple Instances)
  # =============================================================================
  evaluation-engine:
    build:
      context: ./services/evaluation-engine
      dockerfile: Dockerfile
    container_name: defi-evaluation-engine
    environment:
      - SERVICE_NAME=evaluation-engine
      - PORT=8082
      - LOG_LEVEL=${LOG_LEVEL:-info}
      - DATABASE_URL=postgres://defi:${DB_PASSWORD:-secure_password}@postgres:5432/defi_portfolio?sslmode=disable
      - REDIS_URL=redis://redis:6379/1
      
      # Evaluation Parameters (from images)
      - MIN_TVL_THRESHOLD=50000000      # $50M minimum
      - MAX_POOL_ALLOCATION=0.05         # 5% max per pool
      - MIN_LIQUIDITY_RATIO=20           # 20x minimum
      - REQUIRED_PROTOCOLS=Curve,Pendle,Spectra,Morpho,AAVE,Compound
      - MIN_PROTOCOL_COUNT=2
      - BASE_MARKET_RATE=0.045           # 4.5% risk-free rate
      - APY_STABILITY_DAYS=30            # 30 days for stability check
      
      # Worker Configuration
      - WORKER_COUNT=4
      - MAX_CONCURRENT_EVALUATIONS=10
      - CACHE_TTL=300
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./services/evaluation-engine/config:/app/config:ro
    networks:
      - defi-network
    ports:
      - "8082:8082"
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:8082/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped
    deploy:
      replicas: 2  # Run 2 instances for parallel processing
      resources:
        limits:
          memory: 1G
          cpus: '2.0'
        reservations:
          memory: 512M
          cpus: '1.0'

  # =============================================================================
  # Data Aggregator - Multi-Source Data Collection (Multiple Workers)
  # =============================================================================
  data-aggregator:
    build:
      context: ./services/data-aggregator
      dockerfile: Dockerfile
    container_name: defi-data-aggregator
    environment:
      - SERVICE_NAME=data-aggregator
      - PORT=8083
      - LOG_LEVEL=${LOG_LEVEL:-info}
      - DATABASE_URL=postgres://defi:${DB_PASSWORD:-secure_password}@postgres:5432/defi_portfolio?sslmode=disable
      - REDIS_URL=redis://redis:6379/2
      
      # API Keys for Data Sources
      - DEFILLAMA_ENABLED=true
      - DUNE_API_KEY=${DUNE_API_KEY}
      - DUNE_ENABLED=${DUNE_ENABLED:-false}
      - GITHUB_TOKEN=${GITHUB_TOKEN}
      - GITHUB_ENABLED=${GITHUB_ENABLED:-false}
      - COINGECKO_API_KEY=${COINGECKO_API_KEY}
      - COINGECKO_ENABLED=${COINGECKO_ENABLED:-false}
      - ETHERSCAN_API_KEY=${ETHERSCAN_API_KEY}
      - ETHERSCAN_ENABLED=${ETHERSCAN_ENABLED:-false}
      - THE_GRAPH_API_KEY=${THE_GRAPH_API_KEY}
      - THE_GRAPH_ENABLED=${THE_GRAPH_ENABLED:-false}
      - ALCHEMY_API_KEY=${ALCHEMY_API_KEY}
      - ALCHEMY_ENABLED=${ALCHEMY_ENABLED:-false}
      
      # Collection Configuration
      - WORKER_COUNT=8
      - PARALLEL_REQUESTS=5
      - RETRY_ATTEMPTS=3
      - RETRY_DELAY=5
      - DEFAULT_TIMEOUT=30
      - CACHE_TTL=300
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    volumes:
      - ./services/data-aggregator/config:/app/config:ro
      - ./services/data-aggregator/plugins:/app/plugins:ro
    networks:
      - defi-network
    ports:
      - "8083:8083"
    healthcheck:
      test: ["CMD", "python", "-c", "import requests; requests.get('http://localhost:8083/health')"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped
    deploy:
      replicas: 3  # Run 3 instances for parallel data collection
      resources:
        limits:
          memory: 2G
          cpus: '2.0'
        reservations:
          memory: 1G
          cpus: '1.0'

  # =============================================================================
  # Monitoring Service - Real-time Position Monitoring
  # =============================================================================
  monitoring:
    build:
      context: ./services/monitoring
      dockerfile: Dockerfile
    container_name: defi-monitoring
    environment:
      - SERVICE_NAME=monitoring
      - PORT=8084
      - LOG_LEVEL=${LOG_LEVEL:-info}
      - DATABASE_URL=postgres://defi:${DB_PASSWORD:-secure_password}@postgres:5432/defi_portfolio?sslmode=disable
      - REDIS_URL=redis://redis:6379/3
      
      # Monitoring Thresholds (from rebalancing rules)
      - TVL_DROP_THRESHOLD=0.10          # 10% drop alert
      - APY_DECLINE_DAYS=7               # 7 days below base rate
      - LIQUIDITY_CRISIS_THRESHOLD=0.5   # 50% liquidity drop
      - HEALTH_FACTOR_WARNING=1.5        # Health factor warning level
      
      # Alert Configuration
      - ALERT_COOLDOWN=300               # 5 min between same alerts
      - CHECK_INTERVAL=60                # Check every minute
      - WEBSOCKET_ENABLED=true
      - WEBHOOK_URL=${ALERT_WEBHOOK_URL}
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
      data-aggregator:
        condition: service_healthy
    volumes:
      - ./services/monitoring/config:/app/config:ro
    networks:
      - defi-network
    ports:
      - "8084:8084"
      - "9094:9094"  # Metrics port
    healthcheck:
      test: ["CMD", "python", "-c", "import requests; requests.get('http://localhost:8084/health')"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped
    deploy:
      replicas: 2  # Run 2 instances for redundancy
      resources:
        limits:
          memory: 1G
          cpus: '1.0'
        reservations:
          memory: 512M
          cpus: '0.5'

  # =============================================================================
  # Rebalancer Service - Portfolio Optimization
  # =============================================================================
  rebalancer:
    build:
      context: ./services/rebalancer
      dockerfile: Dockerfile
    container_name: defi-rebalancer
    environment:
      - SERVICE_NAME=rebalancer
      - PORT=8085
      - LOG_LEVEL=${LOG_LEVEL:-info}
      - DATABASE_URL=postgres://defi:${DB_PASSWORD:-secure_password}@postgres:5432/defi_portfolio?sslmode=disable
      - REDIS_URL=redis://redis:6379/4
      
      # Rebalancing Configuration
      - MAX_POSITION_SIZE=0.20           # 20% max per position
      - MIN_POSITION_SIZE=0.01           # 1% minimum
      - REBALANCE_THRESHOLD=0.05         # 5% deviation triggers rebalance
      - GAS_PRICE_LIMIT=100              # Max gas price in gwei
      - SLIPPAGE_TOLERANCE=0.02          # 2% max slippage
      
      # Execution Mode
      - DRY_RUN_MODE=${DRY_RUN_MODE:-true}  # Start in dry-run
      - MANUAL_APPROVAL_REQUIRED=true
      - EXECUTION_DELAY=60                   # 60s delay before execution
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
      evaluation-engine:
        condition: service_healthy
    volumes:
      - ./services/rebalancer/config:/app/config:ro
    networks:
      - defi-network
    ports:
      - "8085:8085"
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost:8085/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '1.0'
        reservations:
          memory: 256M
          cpus: '0.5'

  # =============================================================================
  # Frontend - React Dashboard
  # =============================================================================
  frontend:
    build:
      context: ./services/frontend
      dockerfile: Dockerfile
      args:
        - VITE_API_URL=https://${API_DOMAIN:-api.defi.yourdomain.com}
        - VITE_WS_URL=wss://${API_DOMAIN:-api.defi.yourdomain.com}/ws
    container_name: defi-frontend
    environment:
      # Nginx Proxy Configuration
      - VIRTUAL_HOST=${FRONTEND_DOMAIN:-defi.yourdomain.com}
      - VIRTUAL_PORT=80
      - LETSENCRYPT_HOST=${FRONTEND_DOMAIN:-defi.yourdomain.com}
      - LETSENCRYPT_EMAIL=${ADMIN_EMAIL:-admin@yourdomain.com}
      
      # App Configuration
      - VITE_APP_TITLE=${APP_TITLE:-DeFi Portfolio Manager}
      - VITE_ENABLE_ANALYTICS=${ENABLE_ANALYTICS:-false}
    volumes:
      - ./services/frontend/nginx.conf:/etc/nginx/conf.d/default.conf:ro
    networks:
      - proxy  # Only needs proxy network
    ports:
      - "3000:80"
    healthcheck:
      test: ["CMD", "wget", "--no-verbose", "--tries=1", "--spider", "http://localhost/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 256M
          cpus: '0.5'
        reservations:
          memory: 128M
          cpus: '0.25'

  # =============================================================================
  # DATA LAYER
  # =============================================================================
  
  # PostgreSQL with TimescaleDB for time-series data
  postgres:
    image: timescale/timescaledb:latest-pg15
    container_name: defi-postgres
    environment:
      - POSTGRES_USER=defi
      - POSTGRES_PASSWORD=${DB_PASSWORD:-secure_password}
      - POSTGRES_DB=defi_portfolio
      - POSTGRES_INITDB_ARGS=--encoding=UTF8 --locale=en_US.utf8
      
      # Performance Tuning
      - POSTGRES_MAX_CONNECTIONS=200
      - POSTGRES_SHARED_BUFFERS=256MB
      - POSTGRES_EFFECTIVE_CACHE_SIZE=1GB
      - POSTGRES_MAINTENANCE_WORK_MEM=128MB
      - POSTGRES_WORK_MEM=4MB
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database/init.sql:/docker-entrypoint-initdb.d/01-init.sql:ro
      - ./database/timescale.sql:/docker-entrypoint-initdb.d/02-timescale.sql:ro
      - ./database/schema.sql:/docker-entrypoint-initdb.d/03-schema.sql:ro
    networks:
      - defi-network
    ports:
      - "127.0.0.1:5433:5432"  # Local access only
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U defi -d defi_portfolio"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 30s
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 2G
          cpus: '2.0'
        reservations:
          memory: 1G
          cpus: '1.0'

  # Redis for caching, queues, and pub/sub
  redis:
    image: redis:7-alpine
    container_name: defi-redis
    command: >
      redis-server
      --appendonly yes
      --appendfsync everysec
      --maxmemory 1gb
      --maxmemory-policy allkeys-lru
      --tcp-backlog 511
      --tcp-keepalive 60
      --timeout 0
    volumes:
      - redis_data:/data
      - ./redis/redis.conf:/usr/local/etc/redis/redis.conf:ro
    networks:
      - defi-network
    ports:
      - "127.0.0.1:6380:6379"  # Local access only
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 3
      start_period: 10s
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 1G
          cpus: '1.0'
        reservations:
          memory: 512M
          cpus: '0.5'

  # =============================================================================
  # MONITORING STACK (Optional but Recommended)
  # =============================================================================
  
  # Prometheus for metrics collection
  prometheus:
    image: prom/prometheus:latest
    container_name: defi-prometheus
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/usr/share/prometheus/console_libraries'
      - '--web.console.templates=/usr/share/prometheus/consoles'
      - '--storage.tsdb.retention.time=30d'
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml:ro
      - prometheus_data:/prometheus
    networks:
      - defi-network
    ports:
      - "127.0.0.1:9090:9090"
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 1G
          cpus: '1.0'
        reservations:
          memory: 512M
          cpus: '0.5'

  # Grafana for visualization
  grafana:
    image: grafana/grafana:latest
    container_name: defi-grafana
    environment:
      - GF_SECURITY_ADMIN_USER=${GRAFANA_USER:-admin}
      - GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_PASSWORD:-admin}
      - GF_INSTALL_PLUGINS=redis-datasource,grafana-piechart-panel
      
      # Nginx Proxy Configuration (Optional)
      - VIRTUAL_HOST=${GRAFANA_DOMAIN:-grafana.defi.yourdomain.com}
      - VIRTUAL_PORT=3000
      - LETSENCRYPT_HOST=${GRAFANA_DOMAIN:-grafana.defi.yourdomain.com}
      - LETSENCRYPT_EMAIL=${ADMIN_EMAIL:-admin@yourdomain.com}
    volumes:
      - grafana_data:/var/lib/grafana
      - ./monitoring/grafana/dashboards:/etc/grafana/provisioning/dashboards:ro
      - ./monitoring/grafana/datasources:/etc/grafana/provisioning/datasources:ro
    networks:
      - defi-network
      - proxy  # If exposing externally
    ports:
      - "3001:3000"
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '1.0'
        reservations:
          memory: 256M
          cpus: '0.5'

  # =============================================================================
  # SCHEDULER (for periodic tasks)
  # =============================================================================
  scheduler:
    build:
      context: ./services/scheduler
      dockerfile: Dockerfile
    container_name: defi-scheduler
    environment:
      - SERVICE_NAME=scheduler
      - LOG_LEVEL=${LOG_LEVEL:-info}
      - ORCHESTRATOR_URL=http://orchestrator:8081
      - REDIS_URL=redis://redis:6379/5
      
      # Schedule Configuration
      - STRATEGY_SCAN_CRON=*/30 * * * *     # Every 30 minutes
      - PORTFOLIO_REBALANCE_CRON=0 */6 * * * # Every 6 hours
      - DATA_REFRESH_CRON=*/5 * * * *        # Every 5 minutes
      - CLEANUP_CRON=0 2 * * *               # Daily at 2 AM
    depends_on:
      - orchestrator
      - redis
    volumes:
      - ./services/scheduler/config:/app/config:ro
    networks:
      - defi-network
    restart: unless-stopped
    deploy:
      resources:
        limits:
          memory: 256M
          cpus: '0.5'
        reservations:
          memory: 128M
          cpus: '0.25'

# =============================================================================
# VOLUMES
# =============================================================================
volumes:
  postgres_data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: ${DATA_PATH:-./data}/postgres
      
  redis_data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: ${DATA_PATH:-./data}/redis
      
  prometheus_data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: ${DATA_PATH:-./data}/prometheus
      
  grafana_data:
    driver: local
    driver_opts:
      type: none
      o: bind
      device: ${DATA_PATH:-./data}/grafana

# =============================================================================
# NETWORKS
# =============================================================================
networks:
  # Internal network for service communication
  defi-network:
    driver: bridge
    name: defi_internal
    ipam:
      driver: default
      config:
        - subnet: 172.28.0.0/16
    driver_opts:
      com.docker.network.bridge.name: br-defi
      
  # External network for nginx-proxy (must already exist)
  proxy:
    external: true
    name: proxy
```

---

## Environment Configuration (.env)

```bash
# =============================================================================
# DOMAIN CONFIGURATION (REQUIRED)
# =============================================================================
FRONTEND_DOMAIN=defi.yourdomain.com
API_DOMAIN=api.defi.yourdomain.com
GRAFANA_DOMAIN=grafana.defi.yourdomain.com
ADMIN_EMAIL=admin@yourdomain.com

# =============================================================================
# SECURITY (CHANGE ALL DEFAULTS!)
# =============================================================================
DB_PASSWORD=your_secure_database_password_here
JWT_SECRET=your_secure_jwt_secret_key_here
GRAFANA_USER=admin
GRAFANA_PASSWORD=your_secure_grafana_password

# =============================================================================
# API KEYS (At least DefiLlama is required)
# =============================================================================
# Required
DEFILLAMA_ENABLED=true

# Optional but recommended
DUNE_API_KEY=your_dune_api_key
DUNE_ENABLED=true

GITHUB_TOKEN=your_github_token
GITHUB_ENABLED=true

COINGECKO_API_KEY=your_coingecko_api_key
COINGECKO_ENABLED=true

ETHERSCAN_API_KEY=your_etherscan_api_key
ETHERSCAN_ENABLED=true

THE_GRAPH_API_KEY=your_graph_api_key
THE_GRAPH_ENABLED=false

ALCHEMY_API_KEY=your_alchemy_api_key
ALCHEMY_ENABLED=false

# =============================================================================
# APPLICATION SETTINGS
# =============================================================================
APP_TITLE=DeFi Portfolio Manager
LOG_LEVEL=info
ENABLE_ANALYTICS=false

# Operational Mode
DRY_RUN_MODE=true  # Start in dry-run mode for safety

# CORS Settings
CORS_ORIGINS=https://defi.yourdomain.com

# Alert Webhook (Optional)
ALERT_WEBHOOK_URL=https://hooks.slack.com/services/YOUR/WEBHOOK/URL

# =============================================================================
# PERFORMANCE TUNING (Optional)
# =============================================================================
# Data directory (for volume mounts)
DATA_PATH=/var/lib/defi-data

# Resource limits can be adjusted in docker-compose.yml
```

---

## Deployment Instructions

### 1. Prerequisites

```bash
# Ensure nginx-proxy is running
docker network ls | grep proxy || docker network create proxy

# Ensure nginx-proxy container is running with proper configuration
# Should have VIRTUAL_HOST support and Let's Encrypt companion

# Create data directories
mkdir -p ./data/{postgres,redis,prometheus,grafana}
chmod -R 755 ./data
```

### 2. Initial Setup

```bash
# Clone repository
git clone https://github.com/your-org/defi-portfolio-manager
cd defi-portfolio-manager

# Copy and configure environment
cp .env.example .env
# Edit .env with your domains and API keys
vim .env

# Validate configuration
docker-compose config

# Pull base images
docker-compose pull
```

### 3. Build Services

```bash
# Build all services
docker-compose build

# Or build specific service
docker-compose build evaluation-engine
```

### 4. Database Initialization

```bash
# Start only the database first
docker-compose up -d postgres redis

# Wait for database to be ready
sleep 10

# Verify database is healthy
docker-compose ps postgres
```

### 5. Start Core Services

```bash
# Start services in order
docker-compose up -d api-gateway orchestrator
docker-compose up -d evaluation-engine data-aggregator
docker-compose up -d monitoring rebalancer
docker-compose up -d frontend scheduler

# Or start all at once
docker-compose up -d
```

### 6. Verify Deployment

```bash
# Check all services are running
docker-compose ps

# Check health status
docker-compose exec api-gateway wget -O- http://localhost:8080/health

# View logs
docker-compose logs -f orchestrator

# Access services
curl https://api.defi.yourdomain.com/health
curl https://defi.yourdomain.com
```

### 7. Monitoring Setup

```bash
# Access Grafana
# https://grafana.defi.yourdomain.com
# Default: admin/admin (change immediately)

# Import dashboards
# Dashboards are auto-provisioned from ./monitoring/grafana/dashboards/
```

---

## Scaling Configuration

### Horizontal Scaling

```bash
# Scale specific services
docker-compose up -d --scale evaluation-engine=3
docker-compose up -d --scale data-aggregator=5
docker-compose up -d --scale monitoring=2

# View scaled services
docker-compose ps
```

### Service Discovery

Services use internal DNS names:
- `orchestrator:8081`
- `evaluation-engine:8082`
- `data-aggregator:8083`
- `monitoring:8084`
- `rebalancer:8085`

Docker's internal load balancer handles routing to scaled instances.

---

## Maintenance Commands

### Backup

```bash
# Database backup
docker-compose exec postgres pg_dump -U defi defi_portfolio > backup_$(date +%Y%m%d).sql

# Redis backup
docker-compose exec redis redis-cli BGSAVE
docker cp defi-redis:/data/dump.rdb ./backups/redis_$(date +%Y%m%d).rdb
```

### Updates

```bash
# Update images
docker-compose pull

# Rebuild and restart services
docker-compose up -d --build

# Rolling update (zero downtime)
docker-compose up -d --no-deps --build api-gateway
# Verify health
docker-compose up -d --no-deps --build evaluation-engine
# Continue for other services...
```

### Troubleshooting

```bash
# View logs
docker-compose logs -f [service-name]

# Enter container
docker-compose exec [service-name] /bin/sh

# Restart service
docker-compose restart [service-name]

# Reset everything
docker-compose down -v
docker-compose up -d
```

---

## Health Monitoring

All services expose health endpoints:

```bash
# Check individual services
curl http://localhost:8080/health  # API Gateway
curl http://localhost:8081/health  # Orchestrator
curl http://localhost:8082/health  # Evaluation Engine
curl http://localhost:8083/health  # Data Aggregator
curl http://localhost:8084/health  # Monitoring
curl http://localhost:8085/health  # Rebalancer

# Prometheus metrics
curl http://localhost:9091/metrics  # Orchestrator metrics
curl http://localhost:9093/metrics  # Data Aggregator metrics
curl http://localhost:9094/metrics  # Monitoring metrics
```

---

## Security Considerations

1. **Network Isolation**: Internal services not exposed externally
2. **HTTPS Only**: All external traffic via nginx-proxy with SSL
3. **Authentication**: JWT tokens for API access
4. **Rate Limiting**: Built into API Gateway
5. **Secrets Management**: Use Docker secrets in production
6. **Database Security**: Restricted connections, strong passwords
7. **Container Security**: Non-root users, minimal base images

---

## Production Checklist

- [ ] Change all default passwords in .env
- [ ] Configure real domain names
- [ ] Set up SSL certificates via Let's Encrypt
- [ ] Configure backup strategy
- [ ] Set up monitoring alerts
- [ ] Test failover scenarios
- [ ] Document runbooks
- [ ] Configure log aggregation
- [ ] Set resource limits appropriately
- [ ] Enable audit logging
- [ ] Test disaster recovery
- [ ] Configure firewall rules
- [ ] Set up VPN access for management
- [ ] Document API keys and rotation schedule
- [ ] Configure automated backups

---

**END OF DOCKER COMPOSE SPECIFICATION**
