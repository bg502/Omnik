# Master Product Requirements Document
## DeFi Portfolio Management System - Complete Architecture

### Document Version
- Version: 1.0.0
- Date: October 2025
- Status: Final
- Audience: Development Team (Claude AI Implementation)

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [System Architecture Overview](#system-architecture-overview)
3. [Component Specifications](#component-specifications)
4. [Service Communication](#service-communication)
5. [Data Flow](#data-flow)
6. [Implementation Phases](#implementation-phases)
7. [Related Documents](#related-documents)

---

## Executive Summary

This document provides the complete specification for building a DeFi Portfolio Management System composed of microservices deployed via Docker Compose. The system automates the evaluation, monitoring, and management of DeFi investment strategies through a multi-stage analysis pipeline.

### Key Objectives
1. **Automate strategy discovery and evaluation** across multiple DeFi protocols
2. **Implement multi-phase scoring algorithm** with strict requirements checking
3. **Provide real-time monitoring** of portfolio positions and market conditions
4. **Enable automated rebalancing** based on predefined triggers
5. **Ensure complete decision transparency** with audit trails

### System Capabilities
- Evaluate 500+ strategies per hour
- Monitor 100+ active positions in real-time
- Support 20+ data source integrations
- Process rebalancing decisions in <5 seconds
- Store complete audit trail for all decisions

---

## System Architecture Overview

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         NGINX PROXY                             │
│                    (External - Already Running)                 │
└────────────────────┬───────────────────────────────────────────┘
                     │
┌────────────────────┼───────────────────────────────────────────┐
│                    │                                            │
│  ┌─────────────────▼──────────────┐  ┌──────────────────────┐ │
│  │                                 │  │                      │ │
│  │     API GATEWAY SERVICE         │  │   FRONTEND SERVICE   │ │
│  │         (Port 8080)             │  │     (Port 3000)      │ │
│  │                                 │  │                      │ │
│  └─────────────────┬──────────────┘  └──────────────────────┘ │
│                    │                                            │
│  ┌─────────────────▼──────────────────────────────────────┐   │
│  │                                                         │   │
│  │                 MESSAGE BUS (Redis Pub/Sub)            │   │
│  │                                                         │   │
│  └────┬──────────┬──────────┬──────────┬─────────────────┘   │
│       │          │          │          │                       │
│  ┌────▼───┐ ┌───▼───┐ ┌───▼───┐ ┌───▼───┐                  │
│  │        │ │       │ │       │ │       │                   │
│  │ ORCH.  │ │ EVAL. │ │ DATA  │ │ MON.  │                   │
│  │SERVICE │ │ENGINE │ │AGGREG.│ │SERVICE│                   │
│  │        │ │       │ │       │ │       │                   │
│  └────┬───┘ └───┬───┘ └───┬───┘ └───┬───┘                  │
│       │          │          │          │                       │
│  ┌────▼──────────▼──────────▼──────────▼─────────────────┐   │
│  │                                                         │   │
│  │              SHARED DATA LAYER                         │   │
│  │     (PostgreSQL + TimescaleDB + Redis Cache)          │   │
│  │                                                         │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                    DOCKER NETWORK: defi-network                │
└─────────────────────────────────────────────────────────────────┘
```

### Service Components

| Service | Purpose | Technology | Scaling |
|---------|---------|------------|---------|
| API Gateway | HTTP API, WebSocket, Request routing | Go (Gin) | Horizontal (1-3 instances) |
| Orchestrator | Workflow coordination, Task scheduling | Go | Single instance |
| Evaluation Engine | Strategy scoring, Risk assessment | Go | Horizontal (2-5 workers) |
| Data Aggregator | External API integration, Data normalization | Python | Horizontal (3-10 workers) |
| Monitoring Service | Real-time monitoring, Alert generation | Python (AsyncIO) | Horizontal (2-4 instances) |
| Rebalancer | Portfolio optimization, Trade execution | Go | Single instance (with locks) |
| Frontend | User interface, Visualization | React + Vite | Static (Nginx) |
| PostgreSQL | Primary data storage | PostgreSQL 15 + TimescaleDB | Primary + Read replicas |
| Redis | Cache, Message bus, Queues | Redis 7 | Primary + Replica |

---

## Component Specifications

### Core Services

#### 1. Orchestrator Service
- **Purpose**: Coordinates all workflow execution
- **Responsibilities**:
  - Strategy discovery pipeline management
  - Task distribution to workers
  - Result aggregation
  - Decision flow control
  - Retry and failure handling
- **Key APIs**:
  - `POST /workflow/analyze-strategy`
  - `POST /workflow/rebalance-portfolio`
  - `GET /workflow/status/{id}`
- **Document**: [PRD-Orchestrator-Service.md]

#### 2. Evaluation Engine
- **Purpose**: Implements scoring algorithm
- **Responsibilities**:
  - Basic requirements validation
  - Extended scoring calculation
  - Risk assessment
  - Decision generation
- **Processing Modes**:
  - Batch evaluation (scheduled)
  - On-demand evaluation (API triggered)
  - Continuous re-evaluation (monitoring triggered)
- **Document**: [PRD-Evaluation-Engine.md]

#### 3. Data Aggregator
- **Purpose**: Collects and normalizes external data
- **Responsibilities**:
  - Multi-source data fetching
  - Data validation and cleaning
  - Rate limit management
  - Fallback handling
- **Data Sources**:
  - DefiLlama API
  - Dune Analytics
  - Direct protocol APIs
  - GitHub API
  - Etherscan/Block explorers
- **Document**: [PRD-Data-Aggregator.md]

#### 4. Monitoring Service
- **Purpose**: Real-time position and market monitoring
- **Responsibilities**:
  - TVL tracking
  - APY monitoring
  - Liquidity depth checking
  - Alert generation
  - Health factor monitoring
- **Alert Types**:
  - TVL drop >10%
  - APY degradation
  - Liquidity crisis
  - Protocol issues
- **Document**: [PRD-Monitoring-Service.md]

#### 5. Rebalancer Service
- **Purpose**: Portfolio optimization and rebalancing
- **Responsibilities**:
  - Rebalancing trigger evaluation
  - Optimal allocation calculation
  - Trade simulation
  - Execution planning
- **Triggers**:
  - Scheduled (daily)
  - Event-driven (alerts)
  - Manual (API)
- **Document**: [PRD-Rebalancer-Service.md]

---

## Service Communication

### Communication Patterns

```yaml
Synchronous (HTTP/gRPC):
  API Gateway → Orchestrator: Workflow initiation
  Orchestrator → Evaluation Engine: Scoring requests
  API Gateway → Database: Direct queries

Asynchronous (Redis Pub/Sub):
  Data Aggregator → Message Bus: Data updates
  Monitoring → Message Bus: Alerts
  Evaluation Engine → Message Bus: Scoring complete
  Orchestrator → Message Bus: Task distribution

Event Streaming:
  All Services → Event Store: Audit trail
  Monitoring → Alert Channel: Real-time alerts
  Rebalancer → Execution Channel: Trade signals
```

### Message Formats

```json
// Task Message
{
  "id": "task_123",
  "type": "EVALUATE_STRATEGY",
  "priority": "HIGH",
  "payload": {
    "strategy_id": "curve-3pool-usdc",
    "requested_by": "scheduler",
    "context": {}
  },
  "metadata": {
    "created_at": "2024-01-15T10:00:00Z",
    "retry_count": 0,
    "timeout": 30000
  }
}

// Event Message
{
  "id": "evt_456",
  "type": "STRATEGY_EVALUATED",
  "source": "evaluation-engine",
  "timestamp": "2024-01-15T10:01:00Z",
  "data": {
    "strategy_id": "curve-3pool-usdc",
    "score": 75.5,
    "decision": "APPROVED"
  }
}
```

---

## Data Flow

### Strategy Analysis Flow

```mermaid
graph TB
    A[Strategy Discovery] -->|New Strategy| B[Orchestrator]
    B --> C{Data Collection}
    C -->|Parallel| D[DefiLlama API]
    C -->|Parallel| E[Dune Analytics]
    C -->|Parallel| F[GitHub API]
    C -->|Parallel| G[Protocol APIs]
    
    D --> H[Data Aggregation]
    E --> H
    F --> H
    G --> H
    
    H --> I[Evaluation Engine]
    I --> J{Basic Requirements}
    
    J -->|Fail| K[Reject & Log]
    J -->|Pass| L[Extended Scoring]
    
    L --> M[Risk Assessment]
    M --> N[Decision Generation]
    
    N --> O[Store Result]
    O --> P[Notify Systems]
    
    P --> Q[Monitoring Service]
    P --> R[Rebalancer]
    P --> S[Frontend Updates]
```

### Monitoring Flow

```mermaid
graph LR
    A[Data Sources] -->|Stream| B[Monitoring Service]
    B --> C{Check Thresholds}
    
    C -->|Normal| D[Update Metrics]
    C -->|Alert| E[Generate Alert]
    
    E --> F[Alert Queue]
    F --> G[Orchestrator]
    F --> H[Notification Service]
    F --> I[Rebalancer]
    
    G --> J[Trigger Analysis]
    I --> K[Trigger Rebalancing]
```

---

## Implementation Phases

### Phase 1: Core Infrastructure (Week 1)
- [ ] Setup Docker Compose structure
- [ ] Configure PostgreSQL with TimescaleDB
- [ ] Setup Redis for caching and messaging
- [ ] Implement API Gateway skeleton
- [ ] Create basic frontend structure

### Phase 2: Data Layer (Week 2)
- [ ] Implement Data Aggregator workers
- [ ] Create DefiLlama integration
- [ ] Setup data models and migrations
- [ ] Implement caching strategies
- [ ] Create data validation layer

### Phase 3: Evaluation System (Week 3)
- [ ] Implement Evaluation Engine
- [ ] Create scoring algorithms
- [ ] Build Orchestrator service
- [ ] Setup task distribution
- [ ] Implement decision storage

### Phase 4: Monitoring & Automation (Week 4)
- [ ] Build Monitoring Service
- [ ] Implement alert system
- [ ] Create Rebalancer logic
- [ ] Setup WebSocket connections
- [ ] Build notification system

### Phase 5: Frontend & Testing (Week 5)
- [ ] Complete frontend dashboard
- [ ] Implement decision transparency views
- [ ] Create integration tests
- [ ] Performance testing
- [ ] Documentation completion

---

## Related Documents

### Component PRDs
1. **[PRD-Orchestrator-Service.md](./PRD-Orchestrator-Service.md)** - Workflow coordination specifications
2. **[PRD-Evaluation-Engine.md](./PRD-Evaluation-Engine.md)** - Scoring algorithm implementation
3. **[PRD-Data-Aggregator.md](./PRD-Data-Aggregator.md)** - Data collection and normalization
4. **[PRD-Monitoring-Service.md](./PRD-Monitoring-Service.md)** - Real-time monitoring specifications
5. **[PRD-Rebalancer-Service.md](./PRD-Rebalancer-Service.md)** - Portfolio rebalancing logic

### Technical Specifications
6. **[SPEC-Docker-Compose.md](./SPEC-Docker-Compose.md)** - Complete Docker Compose configuration
7. **[SPEC-API-Contracts.md](./SPEC-API-Contracts.md)** - API endpoint specifications
8. **[SPEC-Database-Schema.md](./SPEC-Database-Schema.md)** - Database design and migrations
9. **[SPEC-Message-Formats.md](./SPEC-Message-Formats.md)** - Inter-service communication specs

### Implementation Guides
10. **[GUIDE-Testing-Strategy.md](./GUIDE-Testing-Strategy.md)** - Testing approach and requirements
11. **[GUIDE-Deployment.md](./GUIDE-Deployment.md)** - Deployment procedures
12. **[GUIDE-Monitoring-Setup.md](./GUIDE-Monitoring-Setup.md)** - Observability configuration

---

## Success Criteria

### Performance Metrics
- Strategy evaluation: <5 seconds per strategy
- Data aggregation: <10 seconds for all sources
- Monitoring latency: <1 second for critical metrics
- API response time: <200ms for 95th percentile
- System availability: 99.9% uptime

### Functional Metrics
- Strategies evaluated: 500+ per hour
- Active monitoring: 100+ positions
- Alert accuracy: >95% true positive rate
- Decision audit: 100% traceable
- Data source reliability: Automatic failover

### Quality Metrics
- Test coverage: >80%
- Documentation: 100% API coverage
- Error rate: <0.1%
- Recovery time: <1 minute
- Data consistency: 100%

---

## Appendix A: Technology Stack

```yaml
Backend:
  - Go 1.21: Orchestrator, Evaluation Engine, API Gateway
  - Python 3.11: Data Aggregator, Monitoring Service
  - PostgreSQL 15: Primary database
  - TimescaleDB: Time-series data
  - Redis 7: Cache and message bus

Frontend:
  - React 18: UI framework
  - Vite: Build tool
  - TailwindCSS: Styling
  - Recharts: Visualizations
  - WebSocket: Real-time updates

Infrastructure:
  - Docker Compose: Container orchestration
  - Nginx Proxy: Reverse proxy (external)
  - Let's Encrypt: SSL certificates
  - Grafana: Metrics visualization
  - Prometheus: Metrics collection

External APIs:
  - DefiLlama: DeFi data
  - Dune Analytics: On-chain analytics
  - GitHub: Repository information
  - Etherscan: Contract verification
  - Protocol APIs: Direct integration
```

---

## Appendix B: Risk Mitigation

| Risk | Impact | Mitigation |
|------|--------|------------|
| API rate limiting | High | Multiple API keys, request queuing, caching |
| Data source failure | High | Fallback sources, cached data, graceful degradation |
| Evaluation errors | Critical | Validation checks, manual override, audit trail |
| System overload | Medium | Auto-scaling, load balancing, circuit breakers |
| Security breach | Critical | API authentication, encrypted storage, audit logs |

---

**END OF MASTER DOCUMENT**

Next Documents:
1. PRD-Orchestrator-Service.md
2. PRD-Evaluation-Engine.md
3. PRD-Data-Aggregator.md
4. PRD-Monitoring-Service.md
5. PRD-Rebalancer-Service.md
6. SPEC-Docker-Compose.md
