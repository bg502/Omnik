# PRD: Orchestrator Service
## Component Specification for Workflow Coordination

### Document Information
- Component: Orchestrator Service
- Version: 1.0.0
- Dependencies: Redis, PostgreSQL, All other services
- Language: Go
- Container Name: defi-orchestrator

---

## 1. Component Overview

### Purpose
The Orchestrator Service is the central coordination hub that manages all workflows, distributes tasks, handles retries, and ensures the complete execution of strategy evaluation and portfolio management processes.

### Key Responsibilities
1. **Workflow Management**: Define and execute multi-step workflows
2. **Task Distribution**: Assign tasks to appropriate workers
3. **State Management**: Track workflow and task states
4. **Retry Logic**: Handle failures with exponential backoff
5. **Result Aggregation**: Collect and combine results from multiple services
6. **Event Publishing**: Notify other services of workflow events

### Service Boundaries
```
INPUTS:
- API Gateway: HTTP requests for workflow initiation
- Message Bus: Events from other services
- Scheduler: Cron-triggered workflows

OUTPUTS:  
- Task Queue: Tasks for worker services
- Event Bus: Workflow status updates
- Database: Workflow state and history
- API Gateway: Workflow results
```

---

## 2. Functional Requirements

### 2.1 Workflow Types

#### Strategy Analysis Workflow
```yaml
Workflow: STRATEGY_ANALYSIS
Steps:
  1. INIT:
     - Validate strategy ID
     - Check if already processing
     - Create workflow record
  
  2. DATA_COLLECTION:
     - Dispatch parallel data tasks:
       * Fetch DefiLlama data
       * Fetch Dune Analytics
       * Fetch GitHub info
       * Fetch audit reports
       * Get protocol data
     - Wait with timeout: 30s
     - Handle partial failures
  
  3. DATA_AGGREGATION:
     - Combine all data sources
     - Validate data completeness
     - Apply data quality checks
  
  4. EVALUATION:
     - Send to Evaluation Engine
     - Wait for scoring result
     - Timeout: 10s
  
  5. DECISION:
     - Apply business rules
     - Generate recommendation
     - Calculate confidence score
  
  6. STORAGE:
     - Store evaluation result
     - Update strategy record
     - Log decision trail
  
  7. NOTIFICATION:
     - Publish evaluation event
     - Trigger monitoring if approved
     - Update frontend via WebSocket
```

#### Portfolio Rebalancing Workflow
```yaml
Workflow: PORTFOLIO_REBALANCE
Steps:
  1. INIT:
     - Lock portfolio (prevent concurrent rebalancing)
     - Snapshot current state
     - Validate trigger conditions
  
  2. ANALYSIS:
     - Fetch current positions
     - Get latest evaluations
     - Calculate optimal allocations
  
  3. SIMULATION:
     - Simulate trades
     - Calculate slippage
     - Estimate gas costs
  
  4. VALIDATION:
     - Check risk limits
     - Verify liquidity
     - Approve/reject changes
  
  5. EXECUTION_PLAN:
     - Generate trade sequence
     - Set execution parameters
     - Create rollback plan
  
  6. NOTIFICATION:
     - Send for manual approval (if required)
     - Log rebalancing decision
     - Update monitoring thresholds
```

#### Monitoring Alert Workflow
```yaml
Workflow: ALERT_RESPONSE
Steps:
  1. RECEIVE_ALERT:
     - Parse alert type
     - Extract affected strategies
     - Determine severity
  
  2. VALIDATION:
     - Verify alert is genuine
     - Check if already handled
     - Apply deduplication
  
  3. ASSESSMENT:
     - Trigger strategy re-evaluation
     - Check portfolio impact
     - Calculate risk exposure
  
  4. ACTION:
     - Generate recommended action
     - Check if auto-action allowed
     - Execute or queue for approval
  
  5. FOLLOW_UP:
     - Schedule re-check
     - Update monitoring parameters
     - Log alert response
```

### 2.2 Task Management

#### Task Definition
```go
type Task struct {
    ID           string        `json:"id"`
    WorkflowID   string        `json:"workflow_id"`
    Type         TaskType      `json:"type"`
    Priority     Priority      `json:"priority"`
    Payload      interface{}   `json:"payload"`
    TargetService string       `json:"target_service"`
    Status       TaskStatus    `json:"status"`
    Retries      int          `json:"retries"`
    MaxRetries   int          `json:"max_retries"`
    Timeout      time.Duration `json:"timeout"`
    CreatedAt    time.Time     `json:"created_at"`
    UpdatedAt    time.Time     `json:"updated_at"`
    CompletedAt  *time.Time    `json:"completed_at"`
    Error        *string       `json:"error"`
    Result       interface{}   `json:"result"`
}

type TaskType string
const (
    TaskDataFetch      TaskType = "DATA_FETCH"
    TaskEvaluation     TaskType = "EVALUATION"
    TaskMonitoring     TaskType = "MONITORING"
    TaskRebalancing    TaskType = "REBALANCING"
    TaskNotification   TaskType = "NOTIFICATION"
)

type Priority int
const (
    PriorityLow    Priority = 1
    PriorityNormal Priority = 5
    PriorityHigh   Priority = 8
    PriorityCritical Priority = 10
)
```

#### Task Distribution Logic
```go
func (o *Orchestrator) distributeTask(task *Task) error {
    // Select target queue based on task type
    queue := o.selectQueue(task.Type, task.TargetService)
    
    // Add priority-based delay
    delay := o.calculateDelay(task.Priority)
    
    // Publish to Redis queue
    return o.redis.Publish(queue, task, delay)
}

func (o *Orchestrator) selectQueue(taskType TaskType, service string) string {
    switch taskType {
    case TaskDataFetch:
        return fmt.Sprintf("queue:data:%s", service)
    case TaskEvaluation:
        return "queue:evaluation"
    case TaskMonitoring:
        return "queue:monitoring"
    default:
        return "queue:general"
    }
}
```

### 2.3 State Management

#### Workflow States
```go
type WorkflowState string
const (
    StateInitialized WorkflowState = "INITIALIZED"
    StateRunning     WorkflowState = "RUNNING"
    StateWaiting     WorkflowState = "WAITING"
    StateCompleted   WorkflowState = "COMPLETED"
    StateFailed      WorkflowState = "FAILED"
    StateCancelled   WorkflowState = "CANCELLED"
    StateRetrying    WorkflowState = "RETRYING"
)

type Workflow struct {
    ID              string                 `json:"id"`
    Type            string                 `json:"type"`
    State           WorkflowState          `json:"state"`
    CurrentStep     int                    `json:"current_step"`
    TotalSteps      int                    `json:"total_steps"`
    Context         map[string]interface{} `json:"context"`
    Tasks           []string               `json:"task_ids"`
    CreatedAt       time.Time              `json:"created_at"`
    UpdatedAt       time.Time              `json:"updated_at"`
    CompletedAt     *time.Time             `json:"completed_at"`
    Error           *string                `json:"error"`
}
```

#### State Transitions
```mermaid
stateDiagram-v2
    [*] --> INITIALIZED
    INITIALIZED --> RUNNING: Start
    RUNNING --> WAITING: Await Tasks
    WAITING --> RUNNING: Tasks Complete
    RUNNING --> COMPLETED: Success
    RUNNING --> FAILED: Error
    FAILED --> RETRYING: Retry
    RETRYING --> RUNNING: Resume
    RETRYING --> FAILED: Max Retries
    RUNNING --> CANCELLED: Cancel
    WAITING --> CANCELLED: Cancel
    COMPLETED --> [*]
    FAILED --> [*]
    CANCELLED --> [*]
```

### 2.4 Error Handling

#### Retry Strategy
```go
type RetryConfig struct {
    MaxAttempts     int           `json:"max_attempts"`
    InitialDelay    time.Duration `json:"initial_delay"`
    MaxDelay        time.Duration `json:"max_delay"`
    BackoffMultiplier float64     `json:"backoff_multiplier"`
    RetryableErrors []string      `json:"retryable_errors"`
}

func (o *Orchestrator) handleTaskFailure(task *Task, err error) error {
    if !o.isRetryable(err) {
        return o.failTask(task, err)
    }
    
    if task.Retries >= task.MaxRetries {
        return o.failTask(task, fmt.Errorf("max retries exceeded: %v", err))
    }
    
    delay := o.calculateBackoff(task.Retries)
    task.Retries++
    task.Status = TaskStatusRetrying
    
    return o.scheduleRetry(task, delay)
}
```

#### Circuit Breaker
```go
type CircuitBreaker struct {
    Service         string
    State           CircuitState
    FailureCount    int
    SuccessCount    int
    LastFailureTime time.Time
    Threshold       int
    Timeout         time.Duration
}

func (o *Orchestrator) checkCircuit(service string) bool {
    cb := o.circuits[service]
    
    switch cb.State {
    case CircuitOpen:
        if time.Since(cb.LastFailureTime) > cb.Timeout {
            cb.State = CircuitHalfOpen
            return true
        }
        return false
    case CircuitHalfOpen:
        return true
    case CircuitClosed:
        return true
    }
    
    return false
}
```

---

## 3. Technical Specifications

### 3.1 API Endpoints

```yaml
# Workflow Management
POST /api/v1/workflow/start:
  body:
    type: string
    params: object
  response:
    workflow_id: string
    status: string

GET /api/v1/workflow/{id}:
  response:
    workflow: Workflow object
    tasks: Task[] array

POST /api/v1/workflow/{id}/cancel:
  response:
    status: string
    cancelled_tasks: int

# Task Management  
GET /api/v1/tasks:
  query:
    workflow_id?: string
    status?: string
    limit?: int
  response:
    tasks: Task[] array

POST /api/v1/tasks/{id}/retry:
  response:
    status: string
    retry_scheduled: boolean

# Health & Metrics
GET /api/v1/health:
  response:
    status: string
    active_workflows: int
    pending_tasks: int
    worker_status: object
```

### 3.2 Message Formats

#### Task Queue Message
```json
{
  "task_id": "task_abc123",
  "workflow_id": "wf_xyz789",
  "type": "DATA_FETCH",
  "service": "defillama",
  "payload": {
    "strategy_id": "curve-3pool-usdc",
    "fields": ["tvl", "apy", "volume"]
  },
  "timeout": 30000,
  "priority": 5,
  "retry_count": 0,
  "created_at": "2024-01-15T10:00:00Z"
}
```

#### Result Message
```json
{
  "task_id": "task_abc123",
  "workflow_id": "wf_xyz789",
  "status": "COMPLETED",
  "result": {
    "tvl": 500000000,
    "apy": 5.2,
    "volume_24h": 10000000
  },
  "execution_time": 1234,
  "completed_at": "2024-01-15T10:00:05Z"
}
```

### 3.3 Database Schema

```sql
-- Workflows table
CREATE TABLE workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    type VARCHAR(50) NOT NULL,
    state VARCHAR(20) NOT NULL,
    current_step INT DEFAULT 0,
    total_steps INT NOT NULL,
    context JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    error TEXT,
    INDEX idx_state (state),
    INDEX idx_type (type),
    INDEX idx_created (created_at DESC)
);

-- Tasks table
CREATE TABLE tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID REFERENCES workflows(id),
    type VARCHAR(50) NOT NULL,
    priority INT DEFAULT 5,
    target_service VARCHAR(50),
    payload JSONB,
    status VARCHAR(20) NOT NULL,
    retries INT DEFAULT 0,
    max_retries INT DEFAULT 3,
    timeout_ms INT DEFAULT 30000,
    result JSONB,
    error TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    INDEX idx_workflow (workflow_id),
    INDEX idx_status (status),
    INDEX idx_type_status (type, status)
);

-- Workflow events table (audit trail)
CREATE TABLE workflow_events (
    id BIGSERIAL PRIMARY KEY,
    workflow_id UUID REFERENCES workflows(id),
    task_id UUID REFERENCES tasks(id),
    event_type VARCHAR(50) NOT NULL,
    event_data JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_workflow_events (workflow_id, created_at)
);
```

### 3.4 Configuration

```yaml
# orchestrator-config.yaml
service:
  name: orchestrator
  port: 8081
  
redis:
  host: redis
  port: 6379
  db: 0
  
database:
  host: postgres
  port: 5432
  name: defi_portfolio
  
workflows:
  strategy_analysis:
    timeout: 120s
    max_retries: 3
    parallel_tasks: 5
    
  portfolio_rebalance:
    timeout: 300s
    max_retries: 1
    requires_approval: true
    
  alert_response:
    timeout: 60s
    max_retries: 2
    auto_execute: false
    
task_queues:
  default_size: 100
  priority_levels: 10
  ttl: 3600
  
circuit_breakers:
  defillama:
    threshold: 5
    timeout: 60s
  dune:
    threshold: 3
    timeout: 120s
    
monitoring:
  metrics_port: 9090
  health_check_interval: 30s
```

---

## 4. Docker Configuration

```dockerfile
# Dockerfile for Orchestrator Service
FROM golang:1.21-alpine AS builder

WORKDIR /app

# Copy go mod files
COPY go.mod go.sum ./
RUN go mod download

# Copy source code
COPY . .

# Build the application
RUN go build -o orchestrator ./cmd/orchestrator

# Final stage
FROM alpine:latest

RUN apk --no-cache add ca-certificates

WORKDIR /root/

# Copy binary from builder
COPY --from=builder /app/orchestrator .
COPY --from=builder /app/config ./config

# Expose port
EXPOSE 8081 9090

# Health check
HEALTHCHECK --interval=30s --timeout=5s --start-period=10s \
  CMD wget --no-verbose --tries=1 --spider http://localhost:8081/health || exit 1

CMD ["./orchestrator"]
```

### Docker Compose Service Definition
```yaml
orchestrator:
  build:
    context: ./services/orchestrator
    dockerfile: Dockerfile
  container_name: defi-orchestrator
  environment:
    - SERVICE_NAME=orchestrator
    - LOG_LEVEL=${LOG_LEVEL:-info}
    - DATABASE_URL=postgres://defi:${DB_PASSWORD}@postgres:5432/defi_portfolio
    - REDIS_URL=redis://redis:6379
    - METRICS_ENABLED=true
    - METRICS_PORT=9090
  depends_on:
    postgres:
      condition: service_healthy
    redis:
      condition: service_healthy
  volumes:
    - ./services/orchestrator/config:/root/config:ro
  ports:
    - "8081:8081"  # API port
    - "9091:9090"  # Metrics port
  networks:
    - defi-network
  restart: unless-stopped
  deploy:
    resources:
      limits:
        memory: 512M
        cpus: '1.0'
      reservations:
        memory: 256M
        cpus: '0.5'
```

---

## 5. Implementation Guidelines

### 5.1 Code Structure

```
orchestrator/
├── cmd/
│   └── orchestrator/
│       └── main.go
├── internal/
│   ├── api/
│   │   ├── handlers.go
│   │   ├── middleware.go
│   │   └── routes.go
│   ├── workflow/
│   │   ├── manager.go
│   │   ├── executor.go
│   │   ├── state.go
│   │   └── types.go
│   ├── tasks/
│   │   ├── distributor.go
│   │   ├── collector.go
│   │   └── retry.go
│   ├── storage/
│   │   ├── postgres.go
│   │   └── redis.go
│   └── monitoring/
│       ├── metrics.go
│       └── health.go
├── pkg/
│   ├── circuit/
│   ├── retry/
│   └── utils/
├── config/
│   └── config.yaml
├── Dockerfile
├── go.mod
└── go.sum
```

### 5.2 Key Implementation Points

1. **Workflow Engine**: Use a state machine pattern with clear transitions
2. **Task Distribution**: Implement priority queues with Redis sorted sets
3. **Parallel Execution**: Use goroutines with proper synchronization
4. **Result Collection**: Implement timeout-based collection with partial results
5. **Error Handling**: Comprehensive error types with retry classification
6. **Monitoring**: Export Prometheus metrics for all operations
7. **Testing**: Unit tests for all components, integration tests for workflows

### 5.3 Testing Requirements

```go
// Unit Test Example
func TestWorkflowExecution(t *testing.T) {
    orchestrator := NewOrchestrator(testConfig)
    
    workflow := &Workflow{
        Type: "STRATEGY_ANALYSIS",
        Context: map[string]interface{}{
            "strategy_id": "test-strategy",
        },
    }
    
    result, err := orchestrator.ExecuteWorkflow(workflow)
    assert.NoError(t, err)
    assert.Equal(t, StateCompleted, result.State)
}

// Integration Test Example
func TestFullStrategyAnalysis(t *testing.T) {
    // Setup test environment with all services
    env := setupTestEnvironment(t)
    defer env.Cleanup()
    
    // Trigger workflow
    response := env.PostJSON("/api/v1/workflow/start", map[string]interface{}{
        "type": "STRATEGY_ANALYSIS",
        "params": map[string]interface{}{
            "strategy_id": "curve-3pool-usdc",
        },
    })
    
    // Wait for completion
    workflowID := response["workflow_id"].(string)
    env.WaitForWorkflow(workflowID, 30*time.Second)
    
    // Verify results
    result := env.GetWorkflow(workflowID)
    assert.Equal(t, "COMPLETED", result.State)
}
```

---

## 6. Performance Requirements

### Metrics
- Workflow initiation: <100ms
- Task distribution: <50ms per task
- State updates: <20ms
- Result aggregation: <500ms for 10 parallel tasks
- Memory usage: <200MB under normal load
- CPU usage: <50% on single core

### Scalability
- Support 100+ concurrent workflows
- Handle 1000+ tasks per minute
- Process 50+ task results per second
- Maintain performance with 10,000+ historical workflows

### Reliability
- Zero message loss with acknowledgments
- Automatic recovery from crashes
- Graceful degradation with service failures
- Complete audit trail for all operations

---

## 7. Monitoring & Observability

### Metrics to Export
```yaml
Workflow Metrics:
  - workflow_started_total (counter)
  - workflow_completed_total (counter)
  - workflow_failed_total (counter)
  - workflow_duration_seconds (histogram)
  - workflow_active_count (gauge)
  
Task Metrics:
  - task_dispatched_total (counter)
  - task_completed_total (counter)
  - task_retried_total (counter)
  - task_queue_size (gauge)
  - task_execution_duration_seconds (histogram)
  
System Metrics:
  - circuit_breaker_state (gauge)
  - redis_connection_pool_size (gauge)
  - database_query_duration_seconds (histogram)
  - api_request_duration_seconds (histogram)
```

### Logging Standards
```json
{
  "timestamp": "2024-01-15T10:00:00Z",
  "level": "INFO",
  "service": "orchestrator",
  "workflow_id": "wf_abc123",
  "task_id": "task_xyz789",
  "message": "Task completed successfully",
  "duration_ms": 1234,
  "metadata": {
    "task_type": "DATA_FETCH",
    "service": "defillama"
  }
}
```

### Alerts
- Workflow failure rate >5%
- Task retry rate >10%
- Circuit breaker open
- Queue size >1000
- Response time >1s

---

## 8. Security Considerations

1. **Authentication**: All API calls require JWT tokens
2. **Authorization**: Role-based access for workflow types
3. **Rate Limiting**: Per-client rate limits
4. **Input Validation**: Strict validation of all inputs
5. **Audit Trail**: Complete logging of all operations
6. **Secrets Management**: Environment variables for sensitive data
7. **Network Security**: Internal network only, no external exposure

---

**END OF ORCHESTRATOR SERVICE PRD**
