# PRD: Rebalancer Service
## Component Specification for Portfolio Optimization & Rebalancing

### Document Information
- Component: Rebalancer Service
- Version: 1.0.0
- Dependencies: PostgreSQL, Redis, Evaluation Engine, Orchestrator
- Language: Go
- Container Name: defi-rebalancer

---

## 1. Component Overview

### Purpose
The Rebalancer Service manages portfolio optimization and executes rebalancing strategies based on triggers from monitoring alerts, scheduled reviews, or manual requests. It calculates optimal allocations, simulates trades, and generates execution plans while respecting risk limits and constraints.

### Key Responsibilities
1. **Portfolio Optimization**: Calculate optimal asset allocations
2. **Rebalancing Triggers**: Process and validate rebalancing conditions
3. **Trade Simulation**: Simulate trades with slippage and gas costs
4. **Execution Planning**: Generate step-by-step execution plans
5. **Risk Management**: Enforce position limits and risk constraints
6. **Rollback Planning**: Create contingency plans for failed executions

### Rebalancing Triggers (from Images)
```
1. Yield Degradation: APY < base rate for 7+ days
2. TVL Alert: Sharp decline indicating risk
3. Better Opportunity: Higher yield at comparable risk
4. Market Structure Shift: Need to adjust stable/ETH ratios
5. Manual Request: User-initiated rebalancing
6. Scheduled Review: Periodic portfolio optimization
```

---

## 2. Functional Requirements

### 2.1 Rebalancing Strategy

#### Portfolio Optimization Model
```go
package rebalancer

import (
    "math"
    "sort"
    "time"
)

type RebalancingStrategy struct {
    MaxPositionSize     float64 // Maximum 20% per position
    MinPositionSize     float64 // Minimum 1% per position
    MaxPositions        int     // Maximum number of positions
    RiskBudget          float64 // Total risk budget
    RebalanceThreshold  float64 // Minimum deviation to trigger (5%)
    TargetStableRatio   float64 // Target stable/volatile ratio
}

type Position struct {
    ID           string
    StrategyID   string
    CurrentValue float64
    CurrentAPY   float64
    RiskScore    float64
    Liquidity    float64
    LastRebalance time.Time
}

type RebalancingPlan struct {
    ID              string
    Timestamp       time.Time
    CurrentPortfolio Portfolio
    TargetPortfolio  Portfolio
    Trades          []Trade
    EstimatedCosts   TradeCosts
    RiskAnalysis    RiskAnalysis
    ApprovalRequired bool
    Status          string
}

type Trade struct {
    Type        TradeType    // BUY, SELL, SWAP
    StrategyID  string
    Amount      float64
    Direction   string       // IN or OUT
    Priority    int          // Execution order
    Slippage    float64      // Expected slippage
    GasEstimate float64      // Estimated gas cost
}

func (r *RebalancerService) CalculateOptimalAllocation(
    currentPortfolio Portfolio,
    availableStrategies []Strategy,
    constraints Constraints,
) (*RebalancingPlan, error) {
    
    plan := &RebalancingPlan{
        ID:               generatePlanID(),
        Timestamp:        time.Now(),
        CurrentPortfolio: currentPortfolio,
    }
    
    // Step 1: Score all available strategies
    scoredStrategies := r.scoreStrategies(availableStrategies, currentPortfolio)
    
    // Step 2: Apply portfolio optimization
    targetAllocations := r.optimizePortfolio(
        scoredStrategies,
        constraints,
        currentPortfolio.TotalValue,
    )
    
    // Step 3: Calculate required trades
    trades := r.calculateTrades(currentPortfolio, targetAllocations)
    
    // Step 4: Simulate execution
    simulation := r.simulateExecution(trades, currentPortfolio)
    
    // Step 5: Risk analysis
    riskAnalysis := r.analyzeRisk(targetAllocations, currentPortfolio)
    
    // Step 6: Create execution plan
    plan.TargetPortfolio = targetAllocations
    plan.Trades = r.optimizeTrades(trades)
    plan.EstimatedCosts = simulation.Costs
    plan.RiskAnalysis = riskAnalysis
    plan.ApprovalRequired = r.requiresApproval(plan)
    
    return plan, nil
}
```

#### Portfolio Scoring Algorithm
```go
func (r *RebalancerService) scoreStrategies(
    strategies []Strategy,
    currentPortfolio Portfolio,
) []ScoredStrategy {
    
    scoredStrategies := make([]ScoredStrategy, 0, len(strategies))
    baseRate := r.config.BaseMarketRate
    
    for _, strategy := range strategies {
        // Get evaluation from Evaluation Engine
        evaluation := r.getLatestEvaluation(strategy.ID)
        if evaluation == nil || evaluation.Action == "REJECT" {
            continue
        }
        
        score := ScoredStrategy{
            Strategy: strategy,
        }
        
        // Calculate opportunity score
        // Based on risk-adjusted returns vs current portfolio
        currentAvgAPY := currentPortfolio.WeightedAPY
        
        // Sharpe Ratio calculation
        excessReturn := evaluation.RiskAdjustedAPY - baseRate
        riskPenalty := evaluation.RiskScore / 100.0
        sharpeRatio := excessReturn / (riskPenalty + 0.01) // Avoid division by zero
        
        score.OpportunityScore = sharpeRatio
        
        // Diversification score
        // Prefer strategies that reduce concentration
        score.DiversificationScore = r.calculateDiversificationScore(
            strategy,
            currentPortfolio,
        )
        
        // Liquidity score (important for exit)
        score.LiquidityScore = strategy.Liquidity / strategy.TVL
        
        // Combined score
        score.TotalScore = (
            score.OpportunityScore * 0.5 +
            score.DiversificationScore * 0.3 +
            score.LiquidityScore * 0.2,
        )
        
        // Apply penalties
        if r.isOverConcentrated(strategy, currentPortfolio) {
            score.TotalScore *= 0.5 // Penalty for concentration
        }
        
        scoredStrategies = append(scoredStrategies, score)
    }
    
    // Sort by total score
    sort.Slice(scoredStrategies, func(i, j int) bool {
        return scoredStrategies[i].TotalScore > scoredStrategies[j].TotalScore
    })
    
    return scoredStrategies
}
```

### 2.2 Rebalancing Triggers Implementation

```go
type RebalancingTrigger struct {
    Type        TriggerType
    Source      string      // MONITOR, SCHEDULER, MANUAL
    Priority    Priority
    Params      map[string]interface{}
    Timestamp   time.Time
}

type TriggerType string
const (
    TriggerAPYDegradation  TriggerType = "APY_DEGRADATION"   // доходность упала
    TriggerTVLAlert        TriggerType = "TVL_ALERT"         // резкое снижение TVL
    TriggerBetterOpportunity TriggerType = "BETTER_OPPORTUNITY" // новая возможность
    TriggerMarketShift     TriggerType = "MARKET_SHIFT"      // изменение рынка
    TriggerScheduled       TriggerType = "SCHEDULED"         // запланировано
    TriggerManual          TriggerType = "MANUAL"            // вручную
)

func (r *RebalancerService) ProcessTrigger(trigger RebalancingTrigger) (*RebalancingPlan, error) {
    // Validate trigger
    if !r.validateTrigger(trigger) {
        return nil, ErrInvalidTrigger
    }
    
    // Check if rebalancing is already in progress
    if r.isRebalancingInProgress() {
        return nil, ErrRebalancingInProgress
    }
    
    // Lock portfolio to prevent concurrent modifications
    lock := r.acquirePortfolioLock()
    defer lock.Release()
    
    // Get current portfolio state
    portfolio := r.getCurrentPortfolio()
    
    // Process based on trigger type
    var plan *RebalancingPlan
    var err error
    
    switch trigger.Type {
    case TriggerAPYDegradation:
        plan, err = r.handleAPYDegradation(portfolio, trigger)
        
    case TriggerTVLAlert:
        plan, err = r.handleTVLAlert(portfolio, trigger)
        
    case TriggerBetterOpportunity:
        plan, err = r.handleBetterOpportunity(portfolio, trigger)
        
    case TriggerMarketShift:
        plan, err = r.handleMarketShift(portfolio, trigger)
        
    case TriggerScheduled:
        plan, err = r.handleScheduledRebalance(portfolio, trigger)
        
    case TriggerManual:
        plan, err = r.handleManualRebalance(portfolio, trigger)
    }
    
    if err != nil {
        return nil, err
    }
    
    // Validate plan
    if err := r.validatePlan(plan); err != nil {
        return nil, err
    }
    
    // Store plan
    r.storePlan(plan)
    
    return plan, nil
}

func (r *RebalancerService) handleAPYDegradation(
    portfolio Portfolio,
    trigger RebalancingTrigger,
) (*RebalancingPlan, error) {
    /*
    Handle case when strategy APY falls below base rate
    As described in images: "доходность стратегии упала до уровня 
    базовой доходности по рынку и не увеличивается уже 7 дней"
    */
    
    affectedStrategy := trigger.Params["strategy_id"].(string)
    currentAPY := trigger.Params["current_apy"].(float64)
    
    // Find replacement strategies
    alternatives := r.findAlternativeStrategies(
        affectedStrategy,
        portfolio,
        MinAPYMultiplier: 1.2, // At least 20% better
    )
    
    if len(alternatives) == 0 {
        // No better alternatives, consider reducing position
        return r.createReductionPlan(portfolio, affectedStrategy, 0.5)
    }
    
    // Create swap plan
    return r.createSwapPlan(portfolio, affectedStrategy, alternatives[0])
}

func (r *RebalancerService) handleTVLAlert(
    portfolio Portfolio,
    trigger RebalancingTrigger,
) (*RebalancingPlan, error) {
    /*
    Handle TVL drop alert
    From images: "сработал аллерт на резкое снижение TVL, 
    угроза depeg, риск ликвидации"
    */
    
    affectedStrategy := trigger.Params["strategy_id"].(string)
    tvlDrop := trigger.Params["tvl_drop_percent"].(float64)
    
    // Assess urgency
    urgency := r.assessUrgency(tvlDrop)
    
    if urgency == UrgencyCritical {
        // Emergency exit
        return r.createEmergencyExitPlan(portfolio, affectedStrategy)
    }
    
    // Partial reduction based on risk
    reductionPercent := r.calculateReductionPercent(tvlDrop)
    return r.createReductionPlan(portfolio, affectedStrategy, reductionPercent)
}
```

### 2.3 Trade Execution Planning

```go
type ExecutionPlan struct {
    ID           string
    RebalancingPlan string
    Steps        []ExecutionStep
    Rollback     []RollbackStep
    Constraints  ExecutionConstraints
    StartTime    time.Time
    EndTime      time.Time
    Status       ExecutionStatus
}

type ExecutionStep struct {
    Order       int
    Type        StepType
    Protocol    string
    Action      string        // WITHDRAW, DEPOSIT, SWAP
    FromAsset   string
    ToAsset     string
    Amount      float64
    GasLimit    uint64
    MaxSlippage float64
    Deadline    time.Time
    Status      StepStatus
    TxHash      string
    Error       error
}

func (r *RebalancerService) CreateExecutionPlan(
    rebalancingPlan *RebalancingPlan,
) (*ExecutionPlan, error) {
    
    plan := &ExecutionPlan{
        ID:              generateExecutionID(),
        RebalancingPlan: rebalancingPlan.ID,
        Steps:           []ExecutionStep{},
        Rollback:        []RollbackStep{},
        Status:          ExecutionPending,
    }
    
    // Sort trades by priority and dependencies
    sortedTrades := r.sortTradesByDependencies(rebalancingPlan.Trades)
    
    // Create execution steps
    for i, trade := range sortedTrades {
        steps := r.createStepsForTrade(trade)
        
        for _, step := range steps {
            step.Order = len(plan.Steps) + 1
            plan.Steps = append(plan.Steps, step)
            
            // Create corresponding rollback step
            rollback := r.createRollbackStep(step)
            plan.Rollback = append([]RollbackStep{rollback}, plan.Rollback...)
        }
    }
    
    // Set execution constraints
    plan.Constraints = ExecutionConstraints{
        MaxGasPrice:      r.config.MaxGasPrice,
        SlippageTolerance: r.config.SlippageTolerance,
        ExecutionWindow:  r.config.ExecutionWindow,
        RequiresApproval: rebalancingPlan.ApprovalRequired,
    }
    
    // Validate execution plan
    if err := r.validateExecutionPlan(plan); err != nil {
        return nil, err
    }
    
    return plan, nil
}

func (r *RebalancerService) createStepsForTrade(trade Trade) []ExecutionStep {
    steps := []ExecutionStep{}
    
    switch trade.Type {
    case TradeTypeSell:
        // Step 1: Withdraw from current position
        steps = append(steps, ExecutionStep{
            Type:        StepWithdraw,
            Protocol:    trade.FromProtocol,
            Action:      "WITHDRAW",
            FromAsset:   trade.FromAsset,
            Amount:      trade.Amount,
            MaxSlippage: trade.Slippage,
        })
        
    case TradeTypeBuy:
        // Step 1: Deposit to new position
        steps = append(steps, ExecutionStep{
            Type:        StepDeposit,
            Protocol:    trade.ToProtocol,
            Action:      "DEPOSIT",
            ToAsset:     trade.ToAsset,
            Amount:      trade.Amount,
            MaxSlippage: trade.Slippage,
        })
        
    case TradeTypeSwap:
        // Step 1: Withdraw from current
        steps = append(steps, ExecutionStep{
            Type:        StepWithdraw,
            Protocol:    trade.FromProtocol,
            Action:      "WITHDRAW",
            FromAsset:   trade.FromAsset,
            Amount:      trade.Amount,
            MaxSlippage: trade.Slippage,
        })
        
        // Step 2: Swap if needed (different assets)
        if trade.FromAsset != trade.ToAsset {
            steps = append(steps, ExecutionStep{
                Type:        StepSwap,
                Protocol:    "1inch", // or other DEX aggregator
                Action:      "SWAP",
                FromAsset:   trade.FromAsset,
                ToAsset:     trade.ToAsset,
                Amount:      trade.Amount,
                MaxSlippage: trade.Slippage,
            })
        }
        
        // Step 3: Deposit to new
        steps = append(steps, ExecutionStep{
            Type:        StepDeposit,
            Protocol:    trade.ToProtocol,
            Action:      "DEPOSIT",
            ToAsset:     trade.ToAsset,
            Amount:      trade.Amount, // Adjust for swap output
            MaxSlippage: trade.Slippage,
        })
    }
    
    return steps
}
```

### 2.4 Risk Management

```go
type RiskManager struct {
    MaxConcentration   float64  // 20% max per position
    MaxRiskScore       float64  // Maximum acceptable risk
    MinLiquidity       float64  // Minimum liquidity requirement
    MaxSlippage        float64  // Maximum acceptable slippage
    EmergencyThreshold float64  // Threshold for emergency actions
}

func (rm *RiskManager) ValidateRebalancingPlan(plan *RebalancingPlan) error {
    // Check position concentration
    for _, position := range plan.TargetPortfolio.Positions {
        concentration := position.Value / plan.TargetPortfolio.TotalValue
        if concentration > rm.MaxConcentration {
            return fmt.Errorf(
                "position %s exceeds max concentration: %.2f%% > %.2f%%",
                position.StrategyID,
                concentration*100,
                rm.MaxConcentration*100,
            )
        }
    }
    
    // Check overall risk
    portfolioRisk := rm.calculatePortfolioRisk(plan.TargetPortfolio)
    if portfolioRisk > rm.MaxRiskScore {
        return fmt.Errorf("portfolio risk too high: %.2f > %.2f", 
            portfolioRisk, rm.MaxRiskScore)
    }
    
    // Check liquidity
    for _, trade := range plan.Trades {
        liquidity := rm.getStrategyLiquidity(trade.StrategyID)
        if liquidity < trade.Amount * rm.MinLiquidity {
            return fmt.Errorf(
                "insufficient liquidity for trade %s: %.2f < %.2f",
                trade.StrategyID,
                liquidity,
                trade.Amount * rm.MinLiquidity,
            )
        }
    }
    
    // Check expected slippage
    for _, trade := range plan.Trades {
        expectedSlippage := rm.estimateSlippage(trade)
        if expectedSlippage > rm.MaxSlippage {
            return fmt.Errorf(
                "slippage too high for trade %s: %.2f%% > %.2f%%",
                trade.StrategyID,
                expectedSlippage*100,
                rm.MaxSlippage*100,
            )
        }
    }
    
    return nil
}

func (rm *RiskManager) calculatePortfolioRisk(portfolio Portfolio) float64 {
    // Calculate portfolio-wide risk metrics
    var weightedRisk float64
    var totalWeight float64
    
    for _, position := range portfolio.Positions {
        weight := position.Value / portfolio.TotalValue
        risk := position.RiskScore
        
        weightedRisk += weight * risk
        totalWeight += weight
    }
    
    // Add concentration risk
    concentrationRisk := rm.calculateConcentrationRisk(portfolio)
    
    // Add correlation risk
    correlationRisk := rm.calculateCorrelationRisk(portfolio)
    
    totalRisk := (weightedRisk + concentrationRisk*0.2 + correlationRisk*0.1)
    
    return totalRisk
}
```

### 2.5 Simulation Engine

```go
type SimulationEngine struct {
    GasOracle      GasOracle
    PriceOracle    PriceOracle
    SlippageModel  SlippageModel
}

type SimulationResult struct {
    Success         bool
    FinalPortfolio  Portfolio
    TotalCosts      TradeCosts
    ExecutionTime   time.Duration
    Warnings        []string
    FailureReasons  []string
}

type TradeCosts struct {
    GasCosts        float64
    SlippageCosts   float64
    ProtocolFees    float64
    TotalCosts      float64
}

func (s *SimulationEngine) SimulateRebalancing(
    plan *RebalancingPlan,
    marketConditions MarketConditions,
) (*SimulationResult, error) {
    
    result := &SimulationResult{
        Success: true,
        FinalPortfolio: plan.CurrentPortfolio.Clone(),
        TotalCosts: TradeCosts{},
    }
    
    // Simulate each trade
    for _, trade := range plan.Trades {
        // Estimate gas costs
        gasPrice := s.GasOracle.GetGasPrice()
        gasLimit := s.estimateGasLimit(trade)
        gasCost := float64(gasPrice * gasLimit) / 1e18
        result.TotalCosts.GasCosts += gasCost
        
        // Estimate slippage
        slippage := s.SlippageModel.EstimateSlippage(
            trade.Amount,
            s.getStrategyLiquidity(trade.StrategyID),
        )
        slippageCost := trade.Amount * slippage
        result.TotalCosts.SlippageCosts += slippageCost
        
        // Estimate protocol fees
        protocolFee := s.getProtocolFee(trade.Protocol) * trade.Amount
        result.TotalCosts.ProtocolFees += protocolFee
        
        // Check if trade would succeed
        if !s.wouldTradeSucceed(trade, marketConditions) {
            result.Success = false
            result.FailureReasons = append(
                result.FailureReasons,
                fmt.Sprintf("Trade %s would fail: insufficient liquidity", trade.ID),
            )
            continue
        }
        
        // Update simulated portfolio
        s.applyTradeToPortfolio(&result.FinalPortfolio, trade)
    }
    
    // Calculate total costs
    result.TotalCosts.TotalCosts = (
        result.TotalCosts.GasCosts +
        result.TotalCosts.SlippageCosts +
        result.TotalCosts.ProtocolFees,
    )
    
    // Check if costs are acceptable
    costPercentage := result.TotalCosts.TotalCosts / plan.CurrentPortfolio.TotalValue
    if costPercentage > 0.02 { // 2% max costs
        result.Warnings = append(
            result.Warnings,
            fmt.Sprintf("High rebalancing costs: %.2f%%", costPercentage*100),
        )
    }
    
    return result, nil
}
```

---

## 3. Technical Specifications

### 3.1 API Endpoints

```yaml
# Rebalancing Management
POST /api/v1/rebalance/trigger:
  description: Trigger rebalancing
  body:
    type: string (APY_DEGRADATION|TVL_ALERT|BETTER_OPPORTUNITY|MANUAL)
    params: object
  response:
    plan_id: string
    status: string

GET /api/v1/rebalance/plans:
  description: Get rebalancing plans
  query:
    status?: string
    limit?: int
  response:
    plans: array

GET /api/v1/rebalance/plan/{id}:
  description: Get specific plan details
  response:
    plan: RebalancingPlan

POST /api/v1/rebalance/plan/{id}/approve:
  description: Approve rebalancing plan
  response:
    status: string
    execution_id: string

POST /api/v1/rebalance/plan/{id}/reject:
  description: Reject rebalancing plan
  body:
    reason: string
  response:
    status: string

# Execution
GET /api/v1/rebalance/execution/{id}:
  description: Get execution status
  response:
    execution: ExecutionPlan
    current_step: int
    status: string

POST /api/v1/rebalance/execution/{id}/pause:
  description: Pause execution
  response:
    status: string

POST /api/v1/rebalance/execution/{id}/resume:
  description: Resume execution
  response:
    status: string

POST /api/v1/rebalance/execution/{id}/rollback:
  description: Initiate rollback
  response:
    rollback_id: string
    status: string

# Simulation
POST /api/v1/rebalance/simulate:
  description: Simulate rebalancing
  body:
    current_portfolio: object
    target_allocations: object
  response:
    simulation: SimulationResult
```

### 3.2 Database Schema

```sql
-- Rebalancing plans
CREATE TABLE rebalancing_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trigger_type VARCHAR(50) NOT NULL,
    trigger_source VARCHAR(50),
    current_portfolio JSONB NOT NULL,
    target_portfolio JSONB NOT NULL,
    trades JSONB NOT NULL,
    estimated_costs JSONB,
    risk_analysis JSONB,
    approval_required BOOLEAN DEFAULT TRUE,
    approved_by VARCHAR(100),
    approved_at TIMESTAMP,
    status VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    executed_at TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_created (created_at DESC)
);

-- Execution plans
CREATE TABLE execution_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rebalancing_plan_id UUID REFERENCES rebalancing_plans(id),
    steps JSONB NOT NULL,
    rollback_steps JSONB,
    constraints JSONB,
    current_step INT DEFAULT 0,
    status VARCHAR(20) NOT NULL,
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    error TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_plan (rebalancing_plan_id),
    INDEX idx_status (status)
);

-- Trade history
CREATE TABLE trade_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    execution_plan_id UUID REFERENCES execution_plans(id),
    trade_type VARCHAR(20) NOT NULL,
    from_strategy VARCHAR(200),
    to_strategy VARCHAR(200),
    amount DECIMAL(20,8),
    actual_slippage DECIMAL(10,6),
    gas_used DECIMAL(20,8),
    tx_hash VARCHAR(100),
    status VARCHAR(20),
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_execution (execution_plan_id),
    INDEX idx_executed (executed_at DESC)
);

-- Simulation results
CREATE TABLE simulation_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rebalancing_plan_id UUID,
    success BOOLEAN,
    final_portfolio JSONB,
    total_costs JSONB,
    warnings TEXT[],
    failure_reasons TEXT[],
    simulated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3.3 Configuration

```yaml
# rebalancer-config.yaml
service:
  name: rebalancer
  port: 8085
  
rebalancing:
  # Position limits
  max_position_size: 0.20      # 20% max
  min_position_size: 0.01      # 1% min
  max_positions: 20
  
  # Triggers
  rebalance_threshold: 0.05    # 5% deviation
  apy_decline_days: 7
  tvl_alert_threshold: 0.10
  
  # Risk limits
  max_risk_score: 70
  min_liquidity_ratio: 10
  max_portfolio_risk: 60
  
  # Execution
  max_gas_price: 100           # gwei
  slippage_tolerance: 0.02     # 2%
  execution_window: 3600        # 1 hour
  execution_delay: 60           # 60 seconds
  
  # Simulation
  simulation_iterations: 100
  confidence_threshold: 0.95
  
  # Operational
  dry_run_mode: true           # Start in dry-run
  manual_approval_required: true
  auto_execute_threshold: 10000 # $10k
  
optimization:
  algorithm: mean-variance      # or kelly, equal-weight
  risk_free_rate: 0.045         # 4.5%
  target_return: 0.12           # 12% annual
  
costs:
  gas_buffer: 1.2               # 20% buffer
  protocol_fees:
    curve: 0.0004
    aave: 0.0009
    compound: 0.0
    uniswap: 0.003
```

---

## 4. Docker Configuration

```dockerfile
# Dockerfile for Rebalancer Service
FROM golang:1.21-alpine AS builder

WORKDIR /app

# Copy go modules
COPY go.mod go.sum ./
RUN go mod download

# Copy source code
COPY . .

# Build the application
RUN go build -o rebalancer ./cmd/rebalancer

# Final stage
FROM alpine:latest

RUN apk --no-cache add ca-certificates

WORKDIR /root/

# Copy binary from builder
COPY --from=builder /app/rebalancer .
COPY --from=builder /app/config ./config

# Expose port
EXPOSE 8085

# Health check
HEALTHCHECK --interval=30s --timeout=5s --start-period=10s \
  CMD wget --no-verbose --tries=1 --spider http://localhost:8085/health || exit 1

CMD ["./rebalancer"]
```

### Docker Compose Service
```yaml
rebalancer:
  build:
    context: ./services/rebalancer
    dockerfile: Dockerfile
  container_name: defi-rebalancer
  environment:
    - SERVICE_NAME=rebalancer
    - PORT=8085
    - LOG_LEVEL=${LOG_LEVEL:-info}
    - DATABASE_URL=postgres://defi:${DB_PASSWORD}@postgres:5432/defi_portfolio
    - REDIS_URL=redis://redis:6379/4
    - MAX_POSITION_SIZE=0.20
    - MIN_POSITION_SIZE=0.01
    - REBALANCE_THRESHOLD=0.05
    - GAS_PRICE_LIMIT=100
    - SLIPPAGE_TOLERANCE=0.02
    - DRY_RUN_MODE=${DRY_RUN_MODE:-true}
    - MANUAL_APPROVAL_REQUIRED=true
    - EXECUTION_DELAY=60
    - BASE_MARKET_RATE=0.045
  depends_on:
    postgres:
      condition: service_healthy
    redis:
      condition: service_healthy
    evaluation-engine:
      condition: service_healthy
  volumes:
    - ./services/rebalancer/config:/root/config:ro
  ports:
    - "8085:8085"
  networks:
    - defi-network
  restart: unless-stopped
  deploy:
    resources:
      limits:
        memory: 512M
        cpus: '1.0'
      reservations:
        memory: 256M
        cpus: '0.5'
```

---

## 5. Implementation Guidelines

### 5.1 Code Structure

```
rebalancer/
├── cmd/
│   └── rebalancer/
│       └── main.go
├── internal/
│   ├── api/
│   │   ├── handlers.go
│   │   └── routes.go
│   ├── engine/
│   │   ├── optimizer.go
│   │   ├── simulator.go
│   │   ├── executor.go
│   │   └── risk.go
│   ├── triggers/
│   │   ├── processor.go
│   │   └── validators.go
│   ├── models/
│   │   ├── portfolio.go
│   │   ├── trade.go
│   │   └── plan.go
│   └── storage/
│       └── postgres.go
├── pkg/
│   ├── optimization/
│   │   └── algorithms.go
│   └── simulation/
│       └── monte_carlo.go
├── config/
│   └── config.yaml
├── Dockerfile
└── go.mod
```

### 5.2 Testing Requirements

```go
func TestRebalancingOptimization(t *testing.T) {
    rebalancer := NewRebalancer(testConfig)
    
    currentPortfolio := Portfolio{
        Positions: []Position{
            {StrategyID: "strategy1", Value: 50000, APY: 5.0},
            {StrategyID: "strategy2", Value: 30000, APY: 7.0},
        },
        TotalValue: 80000,
    }
    
    availableStrategies := []Strategy{
        {ID: "strategy3", APY: 10.0, RiskScore: 60},
        {ID: "strategy4", APY: 8.0, RiskScore: 40},
    }
    
    plan, err := rebalancer.CalculateOptimalAllocation(
        currentPortfolio,
        availableStrategies,
        DefaultConstraints(),
    )
    
    assert.NoError(t, err)
    assert.NotNil(t, plan)
    assert.True(t, plan.TargetPortfolio.TotalValue > 0)
}
```

---

## 6. Performance Requirements

- Optimization calculation: <2 seconds for 20 strategies
- Simulation: <5 seconds for 100 iterations
- Trade execution: <100ms per step
- Memory usage: <200MB under normal load

---

## 7. Monitoring & Observability

### Metrics
```yaml
Rebalancing Metrics:
  - rebalancing_triggered_total (counter, by: type)
  - rebalancing_plans_created (counter)
  - rebalancing_executed_total (counter)
  - rebalancing_failed_total (counter)
  - optimization_duration_seconds (histogram)
  - simulation_duration_seconds (histogram)
  - trade_execution_duration_seconds (histogram)
  - portfolio_value (gauge)
  - portfolio_apy (gauge)
```

---

**END OF REBALANCER SERVICE PRD**
