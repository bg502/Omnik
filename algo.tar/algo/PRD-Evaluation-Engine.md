# PRD: Evaluation Engine
## Component Specification for Strategy Scoring & Risk Assessment

### Document Information
- Component: Evaluation Engine
- Version: 1.0.0
- Dependencies: PostgreSQL, Redis
- Language: Go
- Container Name: defi-evaluation-engine

---

## 1. Component Overview

### Purpose
The Evaluation Engine implements the multi-phase strategy evaluation algorithm, performing basic requirements validation, extended scoring, risk assessment, and decision generation based on the criteria shown in the analysis flow.

### Key Responsibilities
1. **Basic Requirements Validation**: Check minimum criteria (8 requirements)
2. **Extended Scoring Model**: Calculate weighted scores across multiple dimensions
3. **Risk Assessment**: Determine risk levels based on comprehensive analysis
4. **Decision Generation**: Produce actionable recommendations
5. **Test Strategy Implementation**: Pre-deployment validation checks

### Algorithm Flow
```
Input Strategy Data
        ↓
Phase 1: Basic Requirements Check
        ↓ (Pass/Fail)
Phase 2: Extended Scoring Model
        ↓
Phase 3: Risk Assessment
        ↓
Phase 4: Decision Generation
        ↓
Output: Evaluation Result
```

---

## 2. Functional Requirements

### 2.1 Basic Requirements Validation (Первичный скоринг)

#### Requirement Checks
```go
type BasicRequirements struct {
    PoolConcentration    RequirementCheck `json:"pool_concentration"`
    YieldTransparency    RequirementCheck `json:"yield_transparency"`
    AuditStatus          RequirementCheck `json:"audit_status"`
    TeamTransparency     RequirementCheck `json:"team_transparency"`
    GithubPresence       RequirementCheck `json:"github_presence"`
    PricingTransparency  RequirementCheck `json:"pricing_transparency"`
    TVLMinimum          RequirementCheck `json:"tvl_minimum"`
    ProtocolDiversity   RequirementCheck `json:"protocol_diversity"`
    LiquidityDepth      RequirementCheck `json:"liquidity_depth"`
}

type RequirementCheck struct {
    Name        string      `json:"name"`
    Description string      `json:"description"`
    Passed      bool        `json:"passed"`
    Value       interface{} `json:"value"`
    Threshold   interface{} `json:"threshold"`
    Critical    bool        `json:"critical"`
    FailReason  string      `json:"fail_reason,omitempty"`
}
```

#### Implementation Logic
```go
func (e *EvaluationEngine) checkBasicRequirements(strategy StrategyData) BasicRequirements {
    requirements := BasicRequirements{}
    
    // 1. Pool Concentration Check (не занимает больше 5% в пуле)
    requirements.PoolConcentration = RequirementCheck{
        Name: "Pool Concentration Limit",
        Description: "Position must not exceed 5% of pool",
        Threshold: 0.05,
        Critical: true,
    }
    maxPosition := strategy.PortfolioValue * 0.05 // 5% of our portfolio
    poolShare := maxPosition / strategy.TVL
    requirements.PoolConcentration.Value = poolShare
    requirements.PoolConcentration.Passed = poolShare <= 0.05
    
    // 2. Yield Transparency (происхождение yield абсолютно прозрачно)
    requirements.YieldTransparency = RequirementCheck{
        Name: "Yield Source Transparency",
        Description: "Complete transparency of yield generation",
        Critical: true,
        Value: strategy.YieldSources,
        Threshold: "All sources documented",
        Passed: e.validateYieldSources(strategy.YieldSources),
    }
    
    // 3. Audit Status (минимум один аудит от известной фирмы)
    requirements.AuditStatus = RequirementCheck{
        Name: "Security Audit",
        Description: "At least one audit from recognized firm",
        Critical: true,
        Value: len(strategy.Audits),
        Threshold: "≥1 recognized audit",
        Passed: e.hasRecognizedAudit(strategy.Audits),
    }
    
    // 4. Team Transparency (команда публична)
    requirements.TeamTransparency = RequirementCheck{
        Name: "Public Team",
        Description: "Team is public with portfolio track record",
        Critical: true,
        Value: strategy.TeamInfo,
        Threshold: "Public team with history",
        Passed: strategy.TeamPublic && strategy.TeamHasPortfolio,
    }
    
    // 5. GitHub Presence (открытый github)
    requirements.GithubPresence = RequirementCheck{
        Name: "Open Source Code",
        Description: "Active GitHub repository",
        Critical: true,
        Value: strategy.GithubURL,
        Threshold: "Active repository",
        Passed: e.validateGithubActivity(strategy.GithubURL, strategy.LastCommit),
    }
    
    // 6. Pricing Transparency (прозрачность ценообразования)
    requirements.PricingTransparency = RequirementCheck{
        Name: "Pricing Mechanism",
        Description: "Full transparency of asset pricing/pegging",
        Critical: true,
        Value: strategy.PricingMechanism,
        Threshold: "Documented mechanism",
        Passed: strategy.PricingMechanism != "" && strategy.PricingMechanism != "unknown",
    }
    
    // 7. TVL Minimum ($50 млн)
    requirements.TVLMinimum = RequirementCheck{
        Name: "Total Value Locked",
        Description: "Minimum TVL requirement",
        Critical: true,
        Value: strategy.TVL,
        Threshold: 50000000, // $50M
        Passed: strategy.TVL >= 50000000,
    }
    
    // 8. Protocol Diversity (листинги на двух крупных defi протоколах)
    requirements.ProtocolDiversity = RequirementCheck{
        Name: "Protocol Listings",
        Description: "Listed on major DeFi protocols",
        Critical: true,
        Value: strategy.ListedProtocols,
        Threshold: "≥2 from: Curve, Pendle, Spectra, Morpho, AAVE",
        Passed: e.countMajorProtocols(strategy.ListedProtocols) >= 2,
    }
    
    // 9. Liquidity Depth (ликвидность минимум в 20 раз больше нашей аллокации)
    requirements.LiquidityDepth = RequirementCheck{
        Name: "Liquidity Depth",
        Description: "Combined liquidity vs allocation",
        Critical: true,
        Value: strategy.Liquidity / maxPosition,
        Threshold: 20.0,
        Passed: strategy.Liquidity >= (maxPosition * 20),
    }
    
    return requirements
}
```

### 2.2 Extended Scoring Model (Расширенная скоринг-модель)

#### Scoring Components
```go
type ExtendedScoring struct {
    TVLScore           ScoreComponent `json:"tvl_score"`
    LiquidityScore     ScoreComponent `json:"liquidity_score"`
    AuditScore         ScoreComponent `json:"audit_score"`
    ProtocolScore      ScoreComponent `json:"protocol_score"`
    TransparencyScore  ScoreComponent `json:"transparency_score"`
    APYStabilityScore  ScoreComponent `json:"apy_stability_score"`
    TotalScore         float64        `json:"total_score"`
    RiskAdjustedAPY    float64        `json:"risk_adjusted_apy"`
}

type ScoreComponent struct {
    Name          string  `json:"name"`
    RawScore      float64 `json:"raw_score"`      // 0-100
    Weight        float64 `json:"weight"`         // 0-1
    WeightedScore float64 `json:"weighted_score"` // RawScore * Weight
    Details       string  `json:"details"`
}
```

#### Scoring Implementation
```go
func (e *EvaluationEngine) calculateExtendedScore(strategy StrategyData) ExtendedScoring {
    scoring := ExtendedScoring{}
    
    // 1. TVL Score (20% weight) - Logarithmic scale
    scoring.TVLScore = e.calculateTVLScore(strategy.TVL)
    scoring.TVLScore.Weight = 0.20
    
    // 2. Liquidity Score (25% weight) - Critical for exit
    scoring.LiquidityScore = e.calculateLiquidityScore(strategy.Liquidity, strategy.TVL)
    scoring.LiquidityScore.Weight = 0.25
    
    // 3. Audit & Security Score (20% weight)
    scoring.AuditScore = e.calculateAuditScore(strategy)
    scoring.AuditScore.Weight = 0.20
    
    // 4. Protocol Diversity Score (15% weight)
    scoring.ProtocolScore = e.calculateProtocolScore(strategy.ListedProtocols)
    scoring.ProtocolScore.Weight = 0.15
    
    // 5. Transparency Score (10% weight)
    scoring.TransparencyScore = e.calculateTransparencyScore(strategy)
    scoring.TransparencyScore.Weight = 0.10
    
    // 6. APY Stability Score (10% weight)
    scoring.APYStabilityScore = e.calculateAPYStability(strategy.HistoricalAPY)
    scoring.APYStabilityScore.Weight = 0.10
    
    // Calculate total score
    components := []ScoreComponent{
        scoring.TVLScore,
        scoring.LiquidityScore,
        scoring.AuditScore,
        scoring.ProtocolScore,
        scoring.TransparencyScore,
        scoring.APYStabilityScore,
    }
    
    totalScore := 0.0
    for i := range components {
        components[i].WeightedScore = components[i].RawScore * components[i].Weight
        totalScore += components[i].WeightedScore
    }
    
    scoring.TotalScore = totalScore
    
    // Calculate risk-adjusted APY
    riskMultiplier := totalScore / 100.0
    scoring.RiskAdjustedAPY = strategy.CurrentAPY * riskMultiplier
    
    return scoring
}

// TVL Score Calculation
func (e *EvaluationEngine) calculateTVLScore(tvl float64) ScoreComponent {
    score := ScoreComponent{
        Name: "Total Value Locked Score",
    }
    
    // Logarithmic scale: $50M=50, $500M=80, $5B=100
    if tvl < 50_000_000 {
        score.RawScore = 0
        score.Details = "Below minimum TVL"
        return score
    }
    
    logTVL := math.Log10(tvl / 1_000_000) // Convert to millions
    logMin := math.Log10(50)              // log(50M)
    logMax := math.Log10(5000)            // log(5B)
    
    rawScore := (logTVL - logMin) / (logMax - logMin) * 50 + 50
    score.RawScore = math.Min(100, math.Max(50, rawScore))
    score.Details = fmt.Sprintf("TVL: $%.2fM", tvl/1_000_000)
    
    return score
}

// Liquidity Score Calculation
func (e *EvaluationEngine) calculateLiquidityScore(liquidity, tvl float64) ScoreComponent {
    score := ScoreComponent{
        Name: "Liquidity Depth Score",
    }
    
    ratio := liquidity / tvl
    
    switch {
    case ratio >= 0.8:
        score.RawScore = 100
        score.Details = "Excellent liquidity (>80% of TVL)"
    case ratio >= 0.5:
        score.RawScore = 85
        score.Details = "Good liquidity (50-80% of TVL)"
    case ratio >= 0.3:
        score.RawScore = 70
        score.Details = "Moderate liquidity (30-50% of TVL)"
    case ratio >= 0.1:
        score.RawScore = 50
        score.Details = "Low liquidity (10-30% of TVL)"
    default:
        score.RawScore = 30
        score.Details = "Poor liquidity (<10% of TVL)"
    }
    
    return score
}

// APY Stability Calculation
func (e *EvaluationEngine) calculateAPYStability(history []APYDataPoint) ScoreComponent {
    score := ScoreComponent{
        Name: "APY Stability Score",
    }
    
    if len(history) < 30 { // Need 30 days of data
        score.RawScore = 50
        score.Details = "Insufficient historical data"
        return score
    }
    
    // Calculate coefficient of variation
    var sum, sumSquares float64
    for _, point := range history {
        sum += point.Value
        sumSquares += point.Value * point.Value
    }
    
    mean := sum / float64(len(history))
    variance := (sumSquares / float64(len(history))) - (mean * mean)
    stdDev := math.Sqrt(variance)
    cv := stdDev / mean
    
    switch {
    case cv <= 0.1:
        score.RawScore = 100
        score.Details = "Very stable APY (CV ≤ 10%)"
    case cv <= 0.2:
        score.RawScore = 85
        score.Details = "Stable APY (CV ≤ 20%)"
    case cv <= 0.3:
        score.RawScore = 70
        score.Details = "Moderate stability (CV ≤ 30%)"
    case cv <= 0.5:
        score.RawScore = 50
        score.Details = "Variable APY (CV ≤ 50%)"
    default:
        score.RawScore = 30
        score.Details = "Highly volatile APY (CV > 50%)"
    }
    
    return score
}
```

### 2.3 Risk Assessment

#### Risk Categories
```go
type RiskAssessment struct {
    OverallRisk     RiskLevel           `json:"overall_risk"`
    RiskFactors     []RiskFactor        `json:"risk_factors"`
    Mitigations     []string            `json:"mitigations"`
    HealthScore     float64             `json:"health_score"`
    RecentAlerts    []Alert             `json:"recent_alerts"`
}

type RiskLevel string
const (
    RiskLow        RiskLevel = "LOW"          // Score 85-100
    RiskMediumLow  RiskLevel = "MEDIUM_LOW"   // Score 70-84
    RiskMedium     RiskLevel = "MEDIUM"       // Score 55-69
    RiskMediumHigh RiskLevel = "MEDIUM_HIGH"  // Score 40-54
    RiskHigh       RiskLevel = "HIGH"         // Score <40
)

type RiskFactor struct {
    Type        string  `json:"type"`
    Severity    string  `json:"severity"`
    Description string  `json:"description"`
    Impact      float64 `json:"impact"` // 0-1
}
```

#### Risk Calculation
```go
func (e *EvaluationEngine) assessRisk(strategy StrategyData, scoring ExtendedScoring) RiskAssessment {
    assessment := RiskAssessment{
        RiskFactors: []RiskFactor{},
        Mitigations: []string{},
    }
    
    // Determine base risk level from score
    score := scoring.TotalScore
    switch {
    case score >= 85:
        assessment.OverallRisk = RiskLow
    case score >= 70:
        assessment.OverallRisk = RiskMediumLow
    case score >= 55:
        assessment.OverallRisk = RiskMedium
    case score >= 40:
        assessment.OverallRisk = RiskMediumHigh
    default:
        assessment.OverallRisk = RiskHigh
    }
    
    // Check specific risk factors
    
    // 1. Impermanent Loss Risk
    if strategy.ILRisk == "high" {
        assessment.RiskFactors = append(assessment.RiskFactors, RiskFactor{
            Type:        "IMPERMANENT_LOSS",
            Severity:    "HIGH",
            Description: "High impermanent loss risk identified",
            Impact:      0.3,
        })
        assessment.OverallRisk = e.increaseRiskLevel(assessment.OverallRisk)
    }
    
    // 2. Recent TVL Drop
    if e.hasRecentTVLDrop(strategy) {
        assessment.RiskFactors = append(assessment.RiskFactors, RiskFactor{
            Type:        "TVL_DECLINE",
            Severity:    "MEDIUM",
            Description: "TVL declined >10% in last 24h",
            Impact:      0.2,
        })
    }
    
    // 3. Concentration Risk
    if len(strategy.ListedProtocols) < 3 {
        assessment.RiskFactors = append(assessment.RiskFactors, RiskFactor{
            Type:        "CONCENTRATION",
            Severity:    "LOW",
            Description: "Limited protocol diversity",
            Impact:      0.1,
        })
    }
    
    // 4. Smart Contract Age
    if strategy.ContractAge < 30 { // days
        assessment.RiskFactors = append(assessment.RiskFactors, RiskFactor{
            Type:        "NEW_CONTRACT",
            Severity:    "MEDIUM",
            Description: fmt.Sprintf("Contract only %d days old", strategy.ContractAge),
            Impact:      0.15,
        })
    }
    
    // Add mitigations
    if strategy.Insurance {
        assessment.Mitigations = append(assessment.Mitigations, "Protocol has insurance coverage")
    }
    if len(strategy.Audits) > 1 {
        assessment.Mitigations = append(assessment.Mitigations, "Multiple security audits completed")
    }
    if strategy.BugBounty > 0 {
        assessment.Mitigations = append(assessment.Mitigations, fmt.Sprintf("Active bug bounty: $%d", strategy.BugBounty))
    }
    
    // Calculate health score
    assessment.HealthScore = e.calculateHealthScore(strategy, assessment)
    
    return assessment
}
```

### 2.4 Decision Generation

#### Decision Types
```go
type EvaluationDecision struct {
    Action           ActionType          `json:"action"`
    Confidence       float64             `json:"confidence"`     // 0-1
    Reasoning        []string            `json:"reasoning"`
    Conditions       []string            `json:"conditions"`
    TestingRequired  []TestRequirement   `json:"testing_required"`
    ExpectedAPY      float64             `json:"expected_apy"`
    RecommendedSize  float64             `json:"recommended_size"`
}

type ActionType string
const (
    ActionStrongBuy  ActionType = "STRONG_BUY"   // Low risk, high APY
    ActionBuy        ActionType = "BUY"          // Good opportunity
    ActionWatch      ActionType = "WATCH"        // Monitor for changes
    ActionCaution    ActionType = "CAUTION"      // Proceed carefully
    ActionAvoid      ActionType = "AVOID"        // High risk
    ActionReject     ActionType = "REJECT"       // Failed requirements
)

type TestRequirement struct {
    Type        string        `json:"type"`
    Description string        `json:"description"`
    Duration    time.Duration `json:"duration"`
    Amount      float64       `json:"amount"`
}
```

#### Decision Logic
```go
func (e *EvaluationEngine) generateDecision(
    strategy StrategyData,
    requirements BasicRequirements,
    scoring ExtendedScoring,
    risk RiskAssessment,
) EvaluationDecision {
    
    decision := EvaluationDecision{
        Reasoning: []string{},
        Conditions: []string{},
        TestingRequired: []TestRequirement{},
    }
    
    // Check if basic requirements passed
    if !e.allRequirementsPassed(requirements) {
        decision.Action = ActionReject
        decision.Confidence = 1.0
        decision.Reasoning = append(decision.Reasoning, "Failed basic requirements")
        for _, req := range e.getFailedRequirements(requirements) {
            decision.Reasoning = append(decision.Reasoning, req.FailReason)
        }
        return decision
    }
    
    // Generate action based on risk and APY
    baseRate := e.config.BaseMarketRate // Current risk-free rate
    
    switch risk.OverallRisk {
    case RiskLow:
        if scoring.RiskAdjustedAPY > baseRate*1.5 {
            decision.Action = ActionStrongBuy
            decision.Confidence = 0.9
            decision.Reasoning = append(decision.Reasoning, "Low risk with attractive returns")
        } else {
            decision.Action = ActionBuy
            decision.Confidence = 0.75
            decision.Reasoning = append(decision.Reasoning, "Low risk profile")
        }
        
    case RiskMediumLow:
        if scoring.RiskAdjustedAPY > baseRate*2 {
            decision.Action = ActionBuy
            decision.Confidence = 0.7
            decision.Reasoning = append(decision.Reasoning, "Good risk/reward ratio")
        } else {
            decision.Action = ActionWatch
            decision.Confidence = 0.6
            decision.Reasoning = append(decision.Reasoning, "Moderate opportunity")
        }
        
    case RiskMedium:
        decision.Action = ActionWatch
        decision.Confidence = 0.5
        decision.Reasoning = append(decision.Reasoning, "Requires monitoring")
        decision.Conditions = append(decision.Conditions, "APY must remain stable for 7 days")
        
    case RiskMediumHigh:
        decision.Action = ActionCaution
        decision.Confidence = 0.4
        decision.Reasoning = append(decision.Reasoning, "Elevated risk levels")
        decision.Conditions = append(decision.Conditions, "Requires manual review")
        
    case RiskHigh:
        decision.Action = ActionAvoid
        decision.Confidence = 0.8
        decision.Reasoning = append(decision.Reasoning, "Risk exceeds acceptable threshold")
    }
    
    // Add testing requirements for BUY actions
    if decision.Action == ActionBuy || decision.Action == ActionStrongBuy {
        decision.TestingRequired = e.generateTestRequirements(strategy, risk)
    }
    
    // Calculate recommended position size
    decision.RecommendedSize = e.calculatePositionSize(strategy, scoring, risk)
    decision.ExpectedAPY = scoring.RiskAdjustedAPY
    
    return decision
}

func (e *EvaluationEngine) generateTestRequirements(
    strategy StrategyData,
    risk RiskAssessment,
) []TestRequirement {
    
    tests := []TestRequirement{
        {
            Type:        "ENTRY_EXIT",
            Description: "Test entry/exit with small amount",
            Duration:    24 * time.Hour,
            Amount:      1000, // $1000 test
        },
        {
            Type:        "STABILITY",
            Description: "Monitor APY stability",
            Duration:    7 * 24 * time.Hour,
            Amount:      5000, // $5000 test
        },
    }
    
    // Add specific tests based on risk factors
    for _, factor := range risk.RiskFactors {
        switch factor.Type {
        case "IMPERMANENT_LOSS":
            tests = append(tests, TestRequirement{
                Type:        "IL_MONITORING",
                Description: "Monitor impermanent loss impact",
                Duration:    14 * 24 * time.Hour,
                Amount:      2000,
            })
        case "NEW_CONTRACT":
            tests = append(tests, TestRequirement{
                Type:        "CONTRACT_INTERACTION",
                Description: "Test all contract functions",
                Duration:    48 * time.Hour,
                Amount:      500,
            })
        }
    }
    
    return tests
}
```

---

## 3. Technical Specifications

### 3.1 API Endpoints

```yaml
# Evaluation Endpoints
POST /api/v1/evaluate:
  description: Evaluate a single strategy
  body:
    strategy_id: string
    strategy_data: object
    portfolio_context: object
  response:
    evaluation_id: string
    result: EvaluationResult

POST /api/v1/evaluate/batch:
  description: Evaluate multiple strategies
  body:
    strategies: array
  response:
    evaluations: array

GET /api/v1/evaluation/{id}:
  description: Get evaluation result
  response:
    evaluation: EvaluationResult

POST /api/v1/evaluate/test:
  description: Run test requirements
  body:
    strategy_id: string
    test_type: string
  response:
    test_id: string
    status: string

# Scoring Endpoints
GET /api/v1/scoring/weights:
  description: Get current scoring weights
  response:
    weights: object

PUT /api/v1/scoring/weights:
  description: Update scoring weights
  body:
    weights: object
  response:
    status: string

# Risk Endpoints
GET /api/v1/risk/factors:
  description: Get risk factor definitions
  response:
    factors: array

GET /api/v1/risk/thresholds:
  description: Get risk thresholds
  response:
    thresholds: object
```

### 3.2 Database Schema

```sql
-- Evaluations table
CREATE TABLE evaluations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    strategy_id VARCHAR(100) NOT NULL,
    workflow_id UUID,
    
    -- Basic Requirements
    basic_passed BOOLEAN NOT NULL,
    basic_results JSONB NOT NULL,
    
    -- Extended Scoring
    total_score DECIMAL(5,2),
    scoring_details JSONB,
    risk_adjusted_apy DECIMAL(10,4),
    
    -- Risk Assessment
    risk_level VARCHAR(20),
    risk_factors JSONB,
    health_score DECIMAL(5,2),
    
    -- Decision
    action VARCHAR(20) NOT NULL,
    confidence DECIMAL(3,2),
    reasoning TEXT[],
    conditions TEXT[],
    
    -- Testing
    testing_required JSONB,
    test_results JSONB,
    
    -- Metadata
    evaluated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    evaluated_by VARCHAR(50),
    version VARCHAR(10),
    
    INDEX idx_strategy (strategy_id),
    INDEX idx_action (action),
    INDEX idx_risk (risk_level),
    INDEX idx_evaluated (evaluated_at DESC)
);

-- Scoring history (for tracking changes)
CREATE TABLE scoring_history (
    id BIGSERIAL PRIMARY KEY,
    evaluation_id UUID REFERENCES evaluations(id),
    component VARCHAR(50),
    raw_score DECIMAL(5,2),
    weight DECIMAL(3,2),
    weighted_score DECIMAL(5,2),
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Test results
CREATE TABLE test_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    evaluation_id UUID REFERENCES evaluations(id),
    strategy_id VARCHAR(100),
    test_type VARCHAR(50),
    status VARCHAR(20),
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    test_amount DECIMAL(20,2),
    results JSONB,
    passed BOOLEAN,
    notes TEXT
);

-- Risk factors reference
CREATE TABLE risk_factors_ref (
    id SERIAL PRIMARY KEY,
    factor_type VARCHAR(50) UNIQUE NOT NULL,
    severity_levels VARCHAR(20)[],
    default_impact DECIMAL(3,2),
    description TEXT,
    mitigation_options TEXT[],
    active BOOLEAN DEFAULT true
);
```

### 3.3 Configuration

```yaml
# evaluation-config.yaml
service:
  name: evaluation-engine
  port: 8082
  workers: 4
  
evaluation:
  # Basic Requirements
  requirements:
    min_tvl: 50000000  # $50M
    max_pool_allocation: 0.05  # 5%
    min_liquidity_ratio: 20
    required_protocols:
      - Curve
      - Pendle
      - Spectra
      - Morpho
      - AAVE
      - Compound
    min_protocol_count: 2
    max_github_inactivity_days: 90
    
  # Scoring Weights
  scoring:
    tvl_weight: 0.20
    liquidity_weight: 0.25
    audit_weight: 0.20
    protocol_weight: 0.15
    transparency_weight: 0.10
    stability_weight: 0.10
    
  # Risk Thresholds
  risk:
    low_threshold: 85
    medium_low_threshold: 70
    medium_threshold: 55
    medium_high_threshold: 40
    tvl_drop_alert: 0.10  # 10%
    apy_decline_days: 7
    
  # Market Parameters
  market:
    base_rate: 0.045  # 4.5% risk-free rate
    
  # Testing Requirements
  testing:
    min_test_amount: 1000
    max_test_amount: 10000
    stability_test_days: 7
    entry_exit_test_hours: 24
```

---

## 4. Docker Configuration

```dockerfile
# Dockerfile for Evaluation Engine
FROM golang:1.21-alpine AS builder

WORKDIR /app

# Copy dependencies
COPY go.mod go.sum ./
RUN go mod download

# Copy source
COPY . .

# Build
RUN go build -o evaluation-engine ./cmd/evaluation

# Final stage
FROM alpine:latest

RUN apk --no-cache add ca-certificates

WORKDIR /root/

# Copy binary
COPY --from=builder /app/evaluation-engine .
COPY --from=builder /app/config ./config

EXPOSE 8082

HEALTHCHECK --interval=30s --timeout=5s \
  CMD wget --no-verbose --tries=1 --spider http://localhost:8082/health || exit 1

CMD ["./evaluation-engine"]
```

### Docker Compose Service
```yaml
evaluation-engine:
  build:
    context: ./services/evaluation-engine
    dockerfile: Dockerfile
  container_name: defi-evaluation-engine
  environment:
    - SERVICE_NAME=evaluation-engine
    - LOG_LEVEL=${LOG_LEVEL:-info}
    - DATABASE_URL=postgres://defi:${DB_PASSWORD}@postgres:5432/defi_portfolio
    - REDIS_URL=redis://redis:6379/1
    - WORKER_COUNT=4
    - MAX_CONCURRENT_EVALUATIONS=10
  depends_on:
    postgres:
      condition: service_healthy
    redis:
      condition: service_healthy
  volumes:
    - ./services/evaluation-engine/config:/root/config:ro
  ports:
    - "8082:8082"
  networks:
    - defi-network
  restart: unless-stopped
  deploy:
    replicas: 2  # Run 2 instances for redundancy
    resources:
      limits:
        memory: 1G
        cpus: '2.0'
      reservations:
        memory: 512M
        cpus: '1.0'
```

---

## 5. Implementation Guidelines

### 5.1 Code Structure

```
evaluation-engine/
├── cmd/
│   └── evaluation/
│       └── main.go
├── internal/
│   ├── api/
│   │   ├── handlers.go
│   │   ├── validation.go
│   │   └── routes.go
│   ├── engine/
│   │   ├── evaluator.go
│   │   ├── requirements.go
│   │   ├── scoring.go
│   │   ├── risk.go
│   │   └── decision.go
│   ├── models/
│   │   ├── strategy.go
│   │   ├── evaluation.go
│   │   └── risk.go
│   ├── storage/
│   │   ├── postgres.go
│   │   └── cache.go
│   └── workers/
│       ├── pool.go
│       └── processor.go
├── pkg/
│   ├── math/
│   │   └── statistics.go
│   ├── validators/
│   │   └── strategy.go
│   └── utils/
├── config/
│   └── config.yaml
├── Dockerfile
└── go.mod
```

### 5.2 Testing Strategy

```go
// Unit Test: Basic Requirements
func TestBasicRequirements(t *testing.T) {
    engine := NewEvaluationEngine(testConfig)
    
    testCases := []struct {
        name     string
        strategy StrategyData
        expected bool
    }{
        {
            name: "All requirements pass",
            strategy: StrategyData{
                TVL:             100_000_000,
                Liquidity:       80_000_000,
                TeamPublic:      true,
                Audits:          []Audit{{Firm: "CertiK"}},
                ListedProtocols: []string{"Curve", "Aave"},
            },
            expected: true,
        },
        {
            name: "TVL below minimum",
            strategy: StrategyData{
                TVL: 10_000_000, // Below $50M
            },
            expected: false,
        },
    }
    
    for _, tc := range testCases {
        t.Run(tc.name, func(t *testing.T) {
            result := engine.checkBasicRequirements(tc.strategy)
            passed := engine.allRequirementsPassed(result)
            assert.Equal(t, tc.expected, passed)
        })
    }
}

// Integration Test: Full Evaluation
func TestFullEvaluation(t *testing.T) {
    engine := NewEvaluationEngine(testConfig)
    
    strategy := loadTestStrategy("curve-3pool-usdc")
    result := engine.Evaluate(strategy)
    
    assert.NotNil(t, result)
    assert.True(t, result.BasicRequirements.Passed)
    assert.Greater(t, result.Scoring.TotalScore, 70.0)
    assert.Equal(t, "BUY", result.Decision.Action)
}
```

---

## 6. Performance Requirements

- Single evaluation: <500ms
- Batch evaluation: <100ms per strategy
- Cache hit ratio: >80%
- Memory per worker: <100MB
- CPU per evaluation: <10% of single core

---

## 7. Monitoring & Observability

### Metrics
```yaml
Evaluation Metrics:
  - evaluations_total (counter, by: action, risk_level)
  - evaluation_duration_seconds (histogram)
  - scoring_components (gauge, by: component)
  - requirements_failed_total (counter, by: requirement)
  - risk_factors_detected (counter, by: type)
  
Performance Metrics:
  - worker_pool_size (gauge)
  - worker_busy_count (gauge)
  - cache_hit_rate (gauge)
  - database_query_duration (histogram)
```

### Logging
```json
{
  "timestamp": "2024-01-15T10:00:00Z",
  "level": "INFO",
  "service": "evaluation-engine",
  "evaluation_id": "eval_123",
  "strategy_id": "curve-3pool",
  "action": "BUY",
  "score": 75.5,
  "risk": "MEDIUM_LOW",
  "duration_ms": 234
}
```

---

**END OF EVALUATION ENGINE PRD**
