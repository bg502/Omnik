# PRD: Data Aggregator Service
## Component Specification for Multi-Source Data Collection

### Document Information
- Component: Data Aggregator Service
- Version: 1.0.0
- Dependencies: PostgreSQL, Redis, External APIs
- Language: Python 3.11
- Container Name: defi-data-aggregator

---

## 1. Component Overview

### Purpose
The Data Aggregator Service is responsible for collecting, normalizing, and caching data from multiple external sources including DefiLlama, Dune Analytics, GitHub, protocol APIs, and blockchain explorers. It implements a plugin architecture for easy extension and handles rate limiting, retries, and fallback strategies.

### Key Responsibilities
1. **Parallel Data Collection**: Fetch data from multiple sources simultaneously
2. **Data Normalization**: Convert diverse data formats to standard schema
3. **Rate Limit Management**: Respect API limits across all sources
4. **Caching Strategy**: Implement intelligent caching with TTL
5. **Fallback Handling**: Use alternative sources when primary fails
6. **Plugin Architecture**: Easy addition of new data sources

### Data Sources Priority
```
Primary Sources:
  - DefiLlama: TVL, APY, Protocol data
  - Dune Analytics: Historical metrics, on-chain data
  
Secondary Sources:
  - Direct Protocol APIs: Real-time data
  - CoinGecko: Price feeds, market data
  - The Graph: Decentralized queries
  
Verification Sources:
  - Etherscan: Contract verification
  - GitHub: Code activity, audits
  - Audit Platforms: Security reports
```

---

## 2. Functional Requirements

### 2.1 Plugin Architecture

#### Base Plugin Interface
```python
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from datetime import datetime
from dataclasses import dataclass

@dataclass
class DataPoint:
    """Standard data point structure"""
    source: str
    timestamp: datetime
    data_type: str
    value: Any
    metadata: Dict[str, Any]
    confidence: float  # 0-1 confidence score

class DataSourcePlugin(ABC):
    """Base class for all data source plugins"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.name = self.__class__.__name__
        self.rate_limiter = None
        self.cache = None
        self.metrics = None
    
    @abstractmethod
    async def fetch_strategy_data(self, strategy_id: str) -> Dict[str, Any]:
        """Fetch comprehensive strategy data"""
        pass
    
    @abstractmethod
    async def fetch_tvl(self, protocol: str) -> float:
        """Fetch Total Value Locked for a protocol"""
        pass
    
    @abstractmethod
    async def fetch_apy(self, pool_id: str) -> float:
        """Fetch current APY for a pool"""
        pass
    
    @abstractmethod
    async def fetch_historical_data(
        self, 
        identifier: str, 
        start_date: datetime, 
        end_date: datetime
    ) -> List[DataPoint]:
        """Fetch historical data points"""
        pass
    
    @abstractmethod
    async def validate_connection(self) -> bool:
        """Test if the data source is accessible"""
        pass
    
    @abstractmethod
    def get_supported_chains(self) -> List[str]:
        """Return list of supported blockchain networks"""
        pass
    
    @abstractmethod
    def get_rate_limits(self) -> Dict[str, int]:
        """Return rate limit configuration"""
        pass
```

### 2.2 DefiLlama Plugin Implementation

```python
import aiohttp
from typing import Dict, List, Optional
import asyncio
from datetime import datetime, timedelta

class DefiLlamaPlugin(DataSourcePlugin):
    """DefiLlama API integration plugin"""
    
    BASE_URL = "https://api.llama.fi"
    YIELDS_URL = "https://yields.llama.fi"
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.session = None
        self.rate_limit = RateLimiter(
            calls=10,
            period=timedelta(seconds=1)
        )
    
    async def initialize(self):
        """Initialize HTTP session"""
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=30)
        )
    
    async def fetch_strategy_data(self, strategy_id: str) -> Dict[str, Any]:
        """
        Fetch comprehensive strategy data from DefiLlama
        Following the process from the images:
        1. Get pool data from /pools endpoint
        2. Extract TVL, APY, and protocol info
        3. Validate against our requirements
        """
        async with self.rate_limit:
            # Fetch pool data
            pool_data = await self._fetch_pool(strategy_id)
            
            # Fetch protocol data
            protocol = pool_data.get('project', '')
            protocol_data = await self._fetch_protocol(protocol)
            
            # Normalize data
            return {
                'source': 'defillama',
                'strategy_id': strategy_id,
                'protocol': protocol,
                'chain': pool_data.get('chain', 'ethereum'),
                'tvl': float(pool_data.get('tvlUsd', 0)),
                'apy': self._calculate_apy(pool_data),
                'apy_breakdown': {
                    'base': pool_data.get('apyBase', 0),
                    'reward': pool_data.get('apyReward', 0),
                    'total': pool_data.get('apy', 0)
                },
                'il_risk': pool_data.get('ilRisk', 'unknown'),
                'exposure': pool_data.get('exposure', 'single'),
                'pool_meta': pool_data.get('poolMeta'),
                'stablecoin': pool_data.get('stablecoin', False),
                'liquidity': float(pool_data.get('tvlUsd', 0)) * 0.8,  # Estimate
                'audits': protocol_data.get('audits', False),
                'audit_links': protocol_data.get('audit_links', []),
                'category': protocol_data.get('category'),
                'twitter': protocol_data.get('twitter'),
                'github': protocol_data.get('github', []),
                'fetch_timestamp': datetime.utcnow().isoformat(),
                'confidence': self._calculate_confidence(pool_data)
            }
    
    async def _fetch_pool(self, pool_id: str) -> Dict:
        """Fetch specific pool data"""
        url = f"{self.YIELDS_URL}/pools"
        async with self.session.get(url) as response:
            data = await response.json()
            # Find specific pool
            for pool in data['data']:
                if pool['pool'] == pool_id:
                    return pool
            raise ValueError(f"Pool {pool_id} not found")
    
    async def fetch_all_pools(self, filters: Dict = None) -> List[Dict]:
        """
        Fetch all pools matching filters
        Implements the filtering process from image 3:
        - TVL range filtering
        - Stablecoin/volatile filtering
        - Sorting by APY/TVL
        """
        url = f"{self.YIELDS_URL}/pools"
        
        async with self.session.get(url) as response:
            data = await response.json()
            pools = data.get('data', [])
        
        # Apply filters as shown in the images
        filtered = []
        for pool in pools:
            # TVL filter (minimum $10M as shown in image)
            tvl = float(pool.get('tvlUsd', 0))
            if filters and filters.get('min_tvl'):
                if tvl < filters['min_tvl']:
                    continue
            
            # Our requirement is $50M minimum
            if tvl < 50_000_000:
                continue
            
            # Stablecoin filter
            if filters and 'stablecoin' in filters:
                if pool.get('stablecoin') != filters['stablecoin']:
                    continue
            
            # IL risk filter (for volatile assets)
            if filters and filters.get('no_il'):
                if pool.get('ilRisk') not in ['no', 'low']:
                    continue
            
            # Chain filter
            if filters and filters.get('chains'):
                if pool.get('chain') not in filters['chains']:
                    continue
            
            filtered.append(pool)
        
        # Sort by APY descending (as shown in image)
        filtered.sort(key=lambda x: float(x.get('apy', 0)), reverse=True)
        
        return filtered
    
    async def fetch_historical_apy(
        self, 
        pool_id: str, 
        days: int = 30
    ) -> List[DataPoint]:
        """
        Fetch historical APY data
        Used for stability scoring
        """
        # DefiLlama provides historical data through chart endpoint
        url = f"{self.YIELDS_URL}/chart/{pool_id}"
        
        async with self.session.get(url) as response:
            data = await response.json()
        
        data_points = []
        for item in data.get('data', []):
            timestamp = datetime.fromtimestamp(item['timestamp'])
            
            # Only include last N days
            if timestamp < datetime.utcnow() - timedelta(days=days):
                continue
            
            data_points.append(DataPoint(
                source='defillama',
                timestamp=timestamp,
                data_type='apy',
                value=float(item.get('apy', 0)),
                metadata={
                    'tvl': item.get('tvlUsd'),
                    'base_apy': item.get('apyBase'),
                    'reward_apy': item.get('apyReward')
                },
                confidence=0.9
            ))
        
        return data_points
    
    def _calculate_apy(self, pool_data: Dict) -> float:
        """
        Calculate total APY from components
        Sometimes DefiLlama shows incorrect totals (as mentioned in images)
        """
        base = float(pool_data.get('apyBase', 0))
        reward = float(pool_data.get('apyReward', 0))
        
        # Use the total if it seems reasonable
        total = float(pool_data.get('apy', 0))
        calculated = base + reward
        
        # If total is way off (like the 39% vs 3.44% example), use calculated
        if abs(total - calculated) > 10:
            return calculated
        
        return total
    
    def _calculate_confidence(self, data: Dict) -> float:
        """Calculate confidence score for data point"""
        confidence = 1.0
        
        # Reduce confidence for missing data
        if not data.get('audits'):
            confidence -= 0.1
        if data.get('ilRisk') == 'unknown':
            confidence -= 0.1
        if not data.get('tvlUsd'):
            confidence -= 0.3
        
        return max(0.0, confidence)
    
    def get_rate_limits(self) -> Dict[str, int]:
        return {
            'requests_per_second': 10,
            'requests_per_minute': 300,
            'requests_per_hour': 10000
        }
```

### 2.3 Dune Analytics Plugin

```python
class DuneAnalyticsPlugin(DataSourcePlugin):
    """Dune Analytics API integration"""
    
    BASE_URL = "https://api.dune.com/api/v1"
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get('api_key')
        if not self.api_key:
            raise ValueError("Dune API key required")
        
        self.headers = {
            'X-Dune-API-Key': self.api_key
        }
    
    async def fetch_strategy_data(self, strategy_id: str) -> Dict[str, Any]:
        """Fetch on-chain metrics from Dune"""
        # Map strategy to Dune query
        query_id = self._get_query_id(strategy_id)
        
        if not query_id:
            return {}
        
        # Execute query
        execution_id = await self._execute_query(query_id)
        
        # Get results
        results = await self._get_results(execution_id)
        
        return self._normalize_results(results)
    
    async def fetch_volatility_metrics(
        self, 
        protocol: str, 
        days: int = 30
    ) -> Dict[str, float]:
        """
        Fetch APY volatility metrics from Dune
        Used for stability scoring
        """
        query = f"""
        SELECT 
            date_trunc('day', time) as day,
            avg(apy) as avg_apy,
            stddev(apy) as stddev_apy,
            min(apy) as min_apy,
            max(apy) as max_apy
        FROM protocol_metrics
        WHERE protocol = '{protocol}'
            AND time >= now() - interval '{days} days'
        GROUP BY 1
        ORDER BY 1
        """
        
        results = await self._run_query(query)
        
        # Calculate coefficient of variation
        if results:
            apys = [r['avg_apy'] for r in results]
            mean = sum(apys) / len(apys)
            variance = sum((x - mean) ** 2 for x in apys) / len(apys)
            stddev = variance ** 0.5
            cv = stddev / mean if mean > 0 else 1.0
            
            return {
                'mean_apy': mean,
                'stddev_apy': stddev,
                'coefficient_variation': cv,
                'min_apy': min(r['min_apy'] for r in results),
                'max_apy': max(r['max_apy'] for r in results)
            }
        
        return {}
```

### 2.4 GitHub Integration Plugin

```python
class GitHubPlugin(DataSourcePlugin):
    """GitHub API integration for code activity and audit verification"""
    
    BASE_URL = "https://api.github.com"
    
    async def fetch_repository_info(self, repo_url: str) -> Dict[str, Any]:
        """
        Fetch repository information
        Check for activity as required in basic requirements
        """
        # Parse owner and repo from URL
        parts = repo_url.rstrip('/').split('/')
        owner = parts[-2]
        repo = parts[-1]
        
        url = f"{self.BASE_URL}/repos/{owner}/{repo}"
        
        async with self.session.get(url, headers=self.headers) as response:
            data = await response.json()
        
        # Get recent commits
        commits = await self._fetch_recent_commits(owner, repo)
        
        # Check for audit reports in repo
        audits = await self._search_audit_files(owner, repo)
        
        return {
            'url': repo_url,
            'stars': data.get('stargazers_count', 0),
            'forks': data.get('forks_count', 0),
            'open_issues': data.get('open_issues_count', 0),
            'created_at': data.get('created_at'),
            'updated_at': data.get('updated_at'),
            'last_commit': commits[0]['date'] if commits else None,
            'commit_count_30d': len([c for c in commits if self._is_recent(c['date'], 30)]),
            'has_audits': len(audits) > 0,
            'audit_files': audits,
            'is_active': self._is_active(data, commits),
            'languages': await self._fetch_languages(owner, repo)
        }
    
    def _is_active(self, repo_data: Dict, commits: List) -> bool:
        """
        Check if repository is active
        Requirement: Must have recent activity
        """
        if not commits:
            return False
        
        last_commit = datetime.fromisoformat(commits[0]['date'].replace('Z', '+00:00'))
        days_since = (datetime.utcnow() - last_commit.replace(tzinfo=None)).days
        
        # Inactive if no commits in 90 days
        return days_since < 90
```

### 2.5 Data Aggregation Manager

```python
class DataAggregationManager:
    """
    Manages parallel data collection from all sources
    Implements the data collection flow from the strategy
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.plugins: Dict[str, DataSourcePlugin] = {}
        self.cache = RedisCache(config['redis'])
        self.storage = PostgresStorage(config['postgres'])
        self.metrics = MetricsCollector()
        
    async def initialize(self):
        """Initialize all plugins"""
        # Load and initialize plugins
        self.plugins['defillama'] = DefiLlamaPlugin(self.config['defillama'])
        self.plugins['dune'] = DuneAnalyticsPlugin(self.config['dune'])
        self.plugins['github'] = GitHubPlugin(self.config['github'])
        self.plugins['coingecko'] = CoinGeckoPlugin(self.config['coingecko'])
        
        for plugin in self.plugins.values():
            await plugin.initialize()
    
    async def collect_strategy_data(
        self, 
        strategy_id: str,
        required_sources: List[str] = None
    ) -> Dict[str, Any]:
        """
        Collect data from all sources in parallel
        This implements the parallel data collection shown in the flow
        """
        if required_sources is None:
            required_sources = list(self.plugins.keys())
        
        # Check cache first
        cache_key = f"strategy:{strategy_id}"
        cached = await self.cache.get(cache_key)
        if cached and self._is_cache_valid(cached):
            return cached
        
        # Parallel data collection
        tasks = []
        for source in required_sources:
            if source in self.plugins:
                task = self._collect_with_timeout(
                    self.plugins[source].fetch_strategy_data(strategy_id),
                    source,
                    timeout=30
                )
                tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Aggregate results
        aggregated = self._aggregate_results(strategy_id, required_sources, results)
        
        # Validate data quality
        aggregated['data_quality'] = self._assess_data_quality(aggregated)
        
        # Cache the result
        await self.cache.set(cache_key, aggregated, ttl=300)  # 5 min cache
        
        # Store in database
        await self.storage.save_strategy_data(aggregated)
        
        return aggregated
    
    async def _collect_with_timeout(
        self, 
        coro, 
        source: str, 
        timeout: int
    ) -> Dict:
        """Collect data with timeout and error handling"""
        try:
            result = await asyncio.wait_for(coro, timeout=timeout)
            self.metrics.record_success(source)
            return {'source': source, 'data': result, 'error': None}
        except asyncio.TimeoutError:
            self.metrics.record_timeout(source)
            return {'source': source, 'data': None, 'error': 'timeout'}
        except Exception as e:
            self.metrics.record_error(source, str(e))
            return {'source': source, 'data': None, 'error': str(e)}
    
    def _aggregate_results(
        self, 
        strategy_id: str,
        sources: List[str],
        results: List[Dict]
    ) -> Dict:
        """
        Aggregate data from multiple sources
        Handle conflicts and missing data
        """
        aggregated = {
            'strategy_id': strategy_id,
            'timestamp': datetime.utcnow().isoformat(),
            'sources': {},
            'consensus': {},
            'conflicts': []
        }
        
        # Store raw results from each source
        for i, source in enumerate(sources):
            if results[i] and not isinstance(results[i], Exception):
                aggregated['sources'][source] = results[i]
        
        # Build consensus values
        # TVL - use highest confidence source
        tvl_values = []
        for source_data in aggregated['sources'].values():
            if source_data and 'data' in source_data and source_data['data']:
                if 'tvl' in source_data['data']:
                    tvl_values.append({
                        'value': source_data['data']['tvl'],
                        'source': source_data['source'],
                        'confidence': source_data['data'].get('confidence', 0.5)
                    })
        
        if tvl_values:
            # Sort by confidence
            tvl_values.sort(key=lambda x: x['confidence'], reverse=True)
            aggregated['consensus']['tvl'] = tvl_values[0]['value']
            
            # Check for conflicts (>10% difference)
            if len(tvl_values) > 1:
                max_tvl = max(v['value'] for v in tvl_values)
                min_tvl = min(v['value'] for v in tvl_values)
                if (max_tvl - min_tvl) / max_tvl > 0.1:
                    aggregated['conflicts'].append({
                        'field': 'tvl',
                        'values': tvl_values
                    })
        
        # Similar aggregation for APY, liquidity, etc.
        aggregated['consensus']['apy'] = self._aggregate_apy(aggregated['sources'])
        aggregated['consensus']['liquidity'] = self._aggregate_liquidity(aggregated['sources'])
        
        return aggregated
    
    def _assess_data_quality(self, aggregated: Dict) -> Dict:
        """
        Assess the quality of aggregated data
        """
        quality = {
            'score': 1.0,
            'issues': [],
            'missing_fields': []
        }
        
        # Check for required fields
        required = ['tvl', 'apy', 'liquidity', 'audits']
        for field in required:
            if field not in aggregated['consensus'] or aggregated['consensus'][field] is None:
                quality['missing_fields'].append(field)
                quality['score'] -= 0.2
        
        # Check for conflicts
        if aggregated['conflicts']:
            quality['issues'].append(f"{len(aggregated['conflicts'])} data conflicts detected")
            quality['score'] -= 0.1 * len(aggregated['conflicts'])
        
        # Check data freshness
        for source_data in aggregated['sources'].values():
            if source_data and 'data' in source_data:
                timestamp = source_data['data'].get('fetch_timestamp')
                if timestamp:
                    age = (datetime.utcnow() - datetime.fromisoformat(timestamp)).seconds
                    if age > 3600:  # Data older than 1 hour
                        quality['issues'].append(f"Stale data from {source_data['source']}")
                        quality['score'] -= 0.05
        
        quality['score'] = max(0, min(1, quality['score']))
        
        return quality
```

### 2.6 Rate Limiting

```python
import asyncio
from datetime import datetime, timedelta
from collections import deque

class RateLimiter:
    """Token bucket rate limiter for API calls"""
    
    def __init__(self, calls: int, period: timedelta):
        self.calls = calls
        self.period = period
        self.calls_made = deque()
        self.lock = asyncio.Lock()
    
    async def __aenter__(self):
        async with self.lock:
            now = datetime.utcnow()
            
            # Remove old calls outside the period
            cutoff = now - self.period
            while self.calls_made and self.calls_made[0] < cutoff:
                self.calls_made.popleft()
            
            # Check if we can make a call
            if len(self.calls_made) >= self.calls:
                # Need to wait
                sleep_until = self.calls_made[0] + self.period
                sleep_time = (sleep_until - now).total_seconds()
                if sleep_time > 0:
                    await asyncio.sleep(sleep_time)
                    # Recursive call to recheck
                    return await self.__aenter__()
            
            # Record this call
            self.calls_made.append(now)
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        pass

class AdaptiveRateLimiter:
    """Adaptive rate limiter that adjusts based on response headers"""
    
    def __init__(self, initial_rate: int = 10):
        self.current_rate = initial_rate
        self.min_rate = 1
        self.max_rate = 100
        self.adjustment_factor = 0.1
        
    def adjust_from_headers(self, headers: Dict):
        """Adjust rate based on API response headers"""
        # Check for rate limit headers
        remaining = headers.get('X-RateLimit-Remaining')
        reset_time = headers.get('X-RateLimit-Reset')
        
        if remaining and int(remaining) < 10:
            # Slow down
            self.current_rate = max(
                self.min_rate,
                self.current_rate * (1 - self.adjustment_factor)
            )
        elif remaining and int(remaining) > 100:
            # Speed up
            self.current_rate = min(
                self.max_rate,
                self.current_rate * (1 + self.adjustment_factor)
            )
```

---

## 3. Technical Specifications

### 3.1 API Endpoints

```yaml
# Data Collection Endpoints
POST /api/v1/collect/strategy:
  description: Trigger data collection for a strategy
  body:
    strategy_id: string
    sources: array[string]
    force_refresh: boolean
  response:
    task_id: string
    status: string

GET /api/v1/collect/status/{task_id}:
  description: Get collection task status
  response:
    status: string
    progress: number
    result: object

POST /api/v1/collect/batch:
  description: Collect data for multiple strategies
  body:
    strategies: array[string]
  response:
    batch_id: string
    tasks: array

# Data Query Endpoints
GET /api/v1/data/strategy/{id}:
  description: Get collected strategy data
  query:
    sources: string (comma-separated)
    max_age: int (seconds)
  response:
    strategy_data: object

GET /api/v1/data/historical/{strategy_id}:
  description: Get historical data
  query:
    metric: string
    start_date: string
    end_date: string
  response:
    data_points: array

# Plugin Management
GET /api/v1/plugins:
  description: List available plugins
  response:
    plugins: array

GET /api/v1/plugins/{name}/status:
  description: Get plugin status
  response:
    name: string
    status: string
    rate_limits: object
    last_error: string

POST /api/v1/plugins/{name}/test:
  description: Test plugin connectivity
  response:
    success: boolean
    latency: number
    error: string
```

### 3.2 Database Schema

```sql
-- Collected data storage
CREATE TABLE collected_data (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    strategy_id VARCHAR(200) NOT NULL,
    source VARCHAR(50) NOT NULL,
    data_type VARCHAR(50) NOT NULL,
    raw_data JSONB NOT NULL,
    normalized_data JSONB,
    confidence DECIMAL(3,2),
    collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_strategy_source (strategy_id, source),
    INDEX idx_collected (collected_at DESC)
);

-- Historical metrics (time-series)
CREATE TABLE metrics_history (
    time TIMESTAMPTZ NOT NULL,
    strategy_id VARCHAR(200) NOT NULL,
    metric VARCHAR(50) NOT NULL,
    value DECIMAL(20,8),
    source VARCHAR(50),
    metadata JSONB
);

-- Create hypertable for time-series data
SELECT create_hypertable('metrics_history', 'time');
CREATE INDEX idx_metrics_strategy ON metrics_history (strategy_id, time DESC);

-- Data source status
CREATE TABLE source_status (
    source VARCHAR(50) PRIMARY KEY,
    status VARCHAR(20),
    last_success TIMESTAMP,
    last_failure TIMESTAMP,
    failure_count INT DEFAULT 0,
    avg_latency_ms INT,
    rate_limit_remaining INT,
    rate_limit_reset TIMESTAMP
);

-- API keys and credentials (encrypted)
CREATE TABLE api_credentials (
    id SERIAL PRIMARY KEY,
    source VARCHAR(50) UNIQUE NOT NULL,
    encrypted_key TEXT NOT NULL,
    key_type VARCHAR(20),
    expires_at TIMESTAMP,
    rate_limit INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 3.3 Configuration

```yaml
# aggregator-config.yaml
service:
  name: data-aggregator
  port: 8083
  workers: 8
  
sources:
  defillama:
    enabled: true
    base_url: https://api.llama.fi
    yields_url: https://yields.llama.fi
    rate_limit: 10  # per second
    timeout: 30
    cache_ttl: 300
    
  dune:
    enabled: true
    base_url: https://api.dune.com/api/v1
    api_key: ${DUNE_API_KEY}
    rate_limit: 5
    timeout: 60
    cache_ttl: 600
    
  github:
    enabled: true
    base_url: https://api.github.com
    token: ${GITHUB_TOKEN}
    rate_limit: 30
    timeout: 20
    
  coingecko:
    enabled: true
    base_url: https://api.coingecko.com/api/v3
    api_key: ${COINGECKO_API_KEY}
    rate_limit: 10
    timeout: 20
    
  etherscan:
    enabled: true
    base_url: https://api.etherscan.io/api
    api_key: ${ETHERSCAN_API_KEY}
    rate_limit: 5
    timeout: 20

cache:
  redis_url: redis://redis:6379/2
  default_ttl: 300
  max_ttl: 3600
  
storage:
  postgres_url: postgres://defi:password@postgres:5432/defi_portfolio
  batch_size: 100
  
collection:
  parallel_requests: 5
  retry_attempts: 3
  retry_delay: 5
  timeout_default: 30
  
monitoring:
  metrics_port: 9093
  health_check_interval: 60
```

---

## 4. Docker Configuration

```dockerfile
# Dockerfile for Data Aggregator
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Create non-root user
RUN useradd -m -u 1000 aggregator && \
    chown -R aggregator:aggregator /app

USER aggregator

# Expose port
EXPOSE 8083

# Health check
HEALTHCHECK --interval=30s --timeout=5s \
  CMD python -c "import requests; requests.get('http://localhost:8083/health')" || exit 1

# Run the application
CMD ["python", "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8083", "--workers", "4"]
```

### requirements.txt
```
fastapi==0.104.1
uvicorn[standard]==0.24.0
aiohttp==3.9.0
asyncpg==0.29.0
redis==5.0.1
pydantic==2.5.0
python-dotenv==1.0.0
tenacity==8.2.3
prometheus-client==0.19.0
cryptography==41.0.7
httpx==0.25.2
beautifulsoup4==4.12.2
pandas==2.1.3
numpy==1.26.2
```

### Docker Compose Service
```yaml
data-aggregator:
  build:
    context: ./services/data-aggregator
    dockerfile: Dockerfile
  container_name: defi-data-aggregator
  environment:
    - SERVICE_NAME=data-aggregator
    - LOG_LEVEL=${LOG_LEVEL:-info}
    - DATABASE_URL=postgres://defi:${DB_PASSWORD}@postgres:5432/defi_portfolio
    - REDIS_URL=redis://redis:6379/2
    # API Keys
    - DUNE_API_KEY=${DUNE_API_KEY}
    - GITHUB_TOKEN=${GITHUB_TOKEN}
    - COINGECKO_API_KEY=${COINGECKO_API_KEY}
    - ETHERSCAN_API_KEY=${ETHERSCAN_API_KEY}
    - THE_GRAPH_API_KEY=${THE_GRAPH_API_KEY}
    # Configuration
    - WORKER_COUNT=8
    - PARALLEL_REQUESTS=5
  depends_on:
    postgres:
      condition: service_healthy
    redis:
      condition: service_healthy
  volumes:
    - ./services/data-aggregator/config:/app/config:ro
    - ./services/data-aggregator/plugins:/app/plugins:ro
  ports:
    - "8083:8083"
  networks:
    - defi-network
  restart: unless-stopped
  deploy:
    replicas: 3  # Run 3 instances for parallel collection
    resources:
      limits:
        memory: 2G
        cpus: '2.0'
      reservations:
        memory: 1G
        cpus: '1.0'
```

---

## 5. Implementation Guidelines

### 5.1 Code Structure

```
data-aggregator/
├── app/
│   ├── main.py
│   ├── api/
│   │   ├── __init__.py
│   │   ├── routes.py
│   │   └── dependencies.py
│   ├── core/
│   │   ├── config.py
│   │   ├── manager.py
│   │   └── scheduler.py
│   ├── plugins/
│   │   ├── base.py
│   │   ├── defillama.py
│   │   ├── dune.py
│   │   ├── github.py
│   │   ├── coingecko.py
│   │   └── etherscan.py
│   ├── models/
│   │   ├── data.py
│   │   └── metrics.py
│   ├── storage/
│   │   ├── postgres.py
│   │   ├── redis.py
│   │   └── timeseries.py
│   ├── utils/
│   │   ├── rate_limiter.py
│   │   ├── retry.py
│   │   └── validation.py
│   └── monitoring/
│       ├── metrics.py
│       └── health.py
├── tests/
│   ├── test_plugins.py
│   ├── test_aggregation.py
│   └── test_api.py
├── config/
│   └── config.yaml
├── requirements.txt
├── Dockerfile
└── README.md
```

### 5.2 Plugin Development Guide

```python
# Example: Adding a new data source plugin

from app.plugins.base import DataSourcePlugin
from typing import Dict, Any
import aiohttp

class NewSourcePlugin(DataSourcePlugin):
    """Template for new data source plugin"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get('base_url')
        self.api_key = config.get('api_key')
    
    async def initialize(self):
        """Setup connection and validate credentials"""
        self.session = aiohttp.ClientSession()
        # Validate API key
        if not await self.validate_connection():
            raise ValueError("Invalid API credentials")
    
    async def fetch_strategy_data(self, strategy_id: str) -> Dict[str, Any]:
        """Implement data fetching logic"""
        # Your implementation here
        pass
    
    async def validate_connection(self) -> bool:
        """Test API connectivity"""
        try:
            # Make test request
            return True
        except Exception:
            return False
    
    def get_rate_limits(self) -> Dict[str, int]:
        return {
            'requests_per_second': 10,
            'requests_per_minute': 500
        }
```

---

## 6. Performance Requirements

- Parallel collection: Support 10+ simultaneous API calls
- Response time: <5s for single strategy data collection
- Cache hit ratio: >70% for recent data
- Memory usage: <500MB per worker
- Data freshness: <5 minutes for active strategies

---

## 7. Monitoring & Observability

### Metrics
```yaml
Collection Metrics:
  - data_collections_total (counter, by: source, status)
  - collection_duration_seconds (histogram, by: source)
  - api_requests_total (counter, by: source, endpoint)
  - api_errors_total (counter, by: source, error_type)
  - cache_hits_total (counter)
  - cache_misses_total (counter)
  
Source Metrics:
  - source_availability (gauge, by: source)
  - source_latency_seconds (histogram, by: source)
  - rate_limit_remaining (gauge, by: source)
  
Data Quality:
  - data_conflicts_total (counter)
  - missing_fields_total (counter, by: field)
  - data_staleness_seconds (histogram)
```

---

**END OF DATA AGGREGATOR PRD**
