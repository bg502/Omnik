# PRD: Monitoring Service
## Component Specification for Real-time Monitoring & Alerts

### Document Information
- Component: Monitoring Service
- Version: 1.0.0
- Dependencies: PostgreSQL, Redis, Data Aggregator
- Language: Python 3.11 (AsyncIO)
- Container Name: defi-monitoring

---

## 1. Component Overview

### Purpose
The Monitoring Service provides real-time tracking of portfolio positions, market conditions, and protocol health. It generates alerts based on configurable thresholds and triggers rebalancing workflows when conditions are met.

### Key Responsibilities
1. **Real-time Monitoring**: Track TVL, APY, liquidity, and health metrics
2. **Alert Generation**: Detect and notify on threshold breaches
3. **Event Detection**: Identify rebalancing triggers
4. **WebSocket Streaming**: Real-time updates to frontend
5. **Historical Tracking**: Record metric changes over time
6. **Health Monitoring**: Track protocol and position health

### Monitoring Scope
```
Portfolio Level:
  - Total portfolio value
  - Risk exposure
  - Allocation balance
  
Position Level:
  - Individual strategy performance
  - APY changes
  - TVL fluctuations
  - Liquidity depth
  
Market Level:
  - Gas prices
  - Market volatility
  - Protocol issues
  
System Level:
  - Data freshness
  - Service health
  - API availability
```

---

## 2. Functional Requirements

### 2.1 Monitoring Rules (from Strategy Images)

#### TVL Monitoring
```python
from dataclasses import dataclass
from typing import List, Optional
from datetime import datetime, timedelta
from enum import Enum

class AlertSeverity(Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"
    EMERGENCY = "EMERGENCY"

@dataclass
class MonitoringRule:
    """Base monitoring rule configuration"""
    name: str
    metric: str
    threshold: float
    comparison: str  # 'gt', 'lt', 'eq', 'change_rate'
    severity: AlertSeverity
    cooldown: int  # seconds between alerts
    auto_action: bool
    action_type: Optional[str]

# Monitoring rules based on rebalancing triggers from images
MONITORING_RULES = [
    # TVL Drop Alert (угроза depeg)
    MonitoringRule(
        name="TVL_SHARP_DECLINE",
        metric="tvl_change_1h",
        threshold=-0.10,  # -10% in 1 hour
        comparison="lt",
        severity=AlertSeverity.CRITICAL,
        cooldown=300,
        auto_action=True,
        action_type="TRIGGER_EVALUATION"
    ),
    
    # APY Degradation (доходность упала до уровня базовой)
    MonitoringRule(
        name="APY_BELOW_BASE_RATE",
        metric="apy_vs_base_rate",
        threshold=1.0,  # APY/BaseRate ratio
        comparison="lt",
        severity=AlertSeverity.WARNING,
        cooldown=3600,
        auto_action=False,
        action_type="MARK_FOR_REBALANCE"
    ),
    
    # Liquidity Crisis
    MonitoringRule(
        name="LIQUIDITY_CRISIS",
        metric="liquidity_change_24h",
        threshold=-0.50,  # -50% in 24 hours
        comparison="lt",
        severity=AlertSeverity.EMERGENCY,
        cooldown=300,
        auto_action=True,
        action_type="EMERGENCY_EXIT"
    ),
    
    # Health Factor Warning
    MonitoringRule(
        name="HEALTH_FACTOR_WARNING",
        metric="health_factor",
        threshold=1.5,
        comparison="lt",
        severity=AlertSeverity.CRITICAL,
        cooldown=60,
        auto_action=True,
        action_type="REDUCE_POSITION"
    ),
    
    # New Opportunity (появление новой возможности)
    MonitoringRule(
        name="BETTER_OPPORTUNITY",
        metric="opportunity_score",
        threshold=1.2,  # 20% better than current
        comparison="gt",
        severity=AlertSeverity.INFO,
        cooldown=3600,
        auto_action=False,
        action_type="SUGGEST_REBALANCE"
    )
]
```

### 2.2 Monitoring Engine

```python
import asyncio
from typing import Dict, List, Any
from datetime import datetime, timedelta
import aioredis
from asyncpg import Pool

class MonitoringEngine:
    """
    Core monitoring engine that tracks all positions and metrics
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.rules = self._load_rules()
        self.positions = {}
        self.alerts = []
        self.websocket_clients = []
        self.check_interval = config.get('check_interval', 60)
        
    async def start(self):
        """Start monitoring loop"""
        # Initialize connections
        self.db_pool = await self._init_db()
        self.redis = await self._init_redis()
        self.data_client = DataAggregatorClient(self.config['aggregator_url'])
        
        # Start monitoring tasks
        await asyncio.gather(
            self._monitoring_loop(),
            self._websocket_server(),
            self._metrics_collector(),
            self._alert_processor()
        )
    
    async def _monitoring_loop(self):
        """Main monitoring loop"""
        while True:
            try:
                # Fetch current positions
                positions = await self._fetch_positions()
                
                # Update metrics for each position
                for position in positions:
                    metrics = await self._fetch_metrics(position)
                    
                    # Check against rules
                    alerts = await self._check_rules(position, metrics)
                    
                    # Process alerts
                    for alert in alerts:
                        await self._process_alert(alert)
                    
                    # Update cache
                    await self._update_cache(position.id, metrics)
                    
                    # Stream to WebSocket
                    await self._stream_update(position, metrics)
                
                # Check portfolio-level metrics
                await self._check_portfolio_health()
                
            except Exception as e:
                logger.error(f"Monitoring error: {e}")
            
            await asyncio.sleep(self.check_interval)
    
    async def _fetch_metrics(self, position: Position) -> Dict:
        """
        Fetch current metrics for a position
        Following the monitoring requirements from images
        """
        strategy_id = position.strategy_id
        
        # Get fresh data from aggregator
        current_data = await self.data_client.get_strategy_data(strategy_id)
        
        # Get historical data for comparison
        historical = await self._get_historical_metrics(strategy_id)
        
        # Calculate derived metrics
        metrics = {
            'strategy_id': strategy_id,
            'timestamp': datetime.utcnow(),
            
            # Current values
            'tvl': current_data['tvl'],
            'apy': current_data['apy'],
            'liquidity': current_data['liquidity'],
            
            # Changes (for alert detection)
            'tvl_change_1h': self._calculate_change(
                current_data['tvl'], 
                historical.get('tvl_1h_ago')
            ),
            'tvl_change_24h': self._calculate_change(
                current_data['tvl'],
                historical.get('tvl_24h_ago')
            ),
            'apy_change_24h': self._calculate_change(
                current_data['apy'],
                historical.get('apy_24h_ago')
            ),
            
            # Comparisons
            'apy_vs_base_rate': current_data['apy'] / self.config['base_market_rate'],
            'liquidity_ratio': current_data['liquidity'] / position.value,
            
            # Health indicators
            'health_factor': self._calculate_health_factor(position, current_data),
            'risk_score': await self._calculate_risk_score(position, current_data),
            
            # Market context
            'gas_price': await self._get_gas_price(),
            'market_volatility': await self._get_market_volatility()
        }
        
        # Store metrics for historical tracking
        await self._store_metrics(metrics)
        
        return metrics
    
    async def _check_rules(
        self, 
        position: Position, 
        metrics: Dict
    ) -> List[Alert]:
        """Check monitoring rules against current metrics"""
        alerts = []
        
        for rule in self.rules:
            # Get metric value
            metric_value = metrics.get(rule.metric)
            if metric_value is None:
                continue
            
            # Check if rule triggers
            triggered = False
            if rule.comparison == 'lt':
                triggered = metric_value < rule.threshold
            elif rule.comparison == 'gt':
                triggered = metric_value > rule.threshold
            elif rule.comparison == 'eq':
                triggered = abs(metric_value - rule.threshold) < 0.001
            elif rule.comparison == 'change_rate':
                triggered = abs(metric_value) > rule.threshold
            
            if triggered:
                # Check cooldown
                if await self._check_cooldown(position.id, rule.name):
                    alert = Alert(
                        rule_name=rule.name,
                        position_id=position.id,
                        strategy_id=position.strategy_id,
                        severity=rule.severity,
                        metric_name=rule.metric,
                        metric_value=metric_value,
                        threshold=rule.threshold,
                        auto_action=rule.auto_action,
                        action_type=rule.action_type,
                        timestamp=datetime.utcnow()
                    )
                    alerts.append(alert)
                    
                    # Update cooldown
                    await self._update_cooldown(position.id, rule.name)
        
        return alerts
    
    async def _process_alert(self, alert: Alert):
        """Process generated alert"""
        # Store alert
        await self._store_alert(alert)
        
        # Send notifications
        await self._send_notifications(alert)
        
        # Execute auto-actions if configured
        if alert.auto_action:
            await self._execute_action(alert)
        
        # Update dashboard
        await self._update_dashboard(alert)
        
        # Log alert
        logger.info(f"Alert triggered: {alert.rule_name} for position {alert.position_id}")
```

### 2.3 Alert Processing

```python
class AlertProcessor:
    """Handles alert processing and notification"""
    
    async def process_alert(self, alert: Alert):
        """Main alert processing logic"""
        # Deduplicate
        if await self._is_duplicate(alert):
            return
        
        # Enrich with context
        alert = await self._enrich_alert(alert)
        
        # Determine notification channels
        channels = self._get_notification_channels(alert.severity)
        
        # Send notifications
        for channel in channels:
            await self._notify(channel, alert)
        
        # Trigger workflows if needed
        if alert.action_type:
            await self._trigger_workflow(alert)
    
    async def _trigger_workflow(self, alert: Alert):
        """
        Trigger appropriate workflow based on alert
        Implements the rebalancing triggers from images
        """
        workflow_mapping = {
            'TRIGGER_EVALUATION': 'STRATEGY_ANALYSIS',
            'MARK_FOR_REBALANCE': 'PORTFOLIO_REBALANCE',
            'EMERGENCY_EXIT': 'EMERGENCY_EXIT_POSITION',
            'REDUCE_POSITION': 'POSITION_REDUCTION',
            'SUGGEST_REBALANCE': 'REBALANCE_SUGGESTION'
        }
        
        workflow_type = workflow_mapping.get(alert.action_type)
        if workflow_type:
            # Call orchestrator to start workflow
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    f"{self.orchestrator_url}/workflow/start",
                    json={
                        'type': workflow_type,
                        'trigger': 'ALERT',
                        'alert_id': alert.id,
                        'params': {
                            'position_id': alert.position_id,
                            'strategy_id': alert.strategy_id,
                            'urgency': alert.severity.value
                        }
                    }
                ) as response:
                    result = await response.json()
                    logger.info(f"Workflow {workflow_type} started: {result['workflow_id']}")
    
    def _get_notification_channels(self, severity: AlertSeverity) -> List[str]:
        """Determine notification channels based on severity"""
        channels = ['database', 'websocket']  # Always log and stream
        
        if severity == AlertSeverity.INFO:
            channels.append('dashboard')
        elif severity == AlertSeverity.WARNING:
            channels.extend(['dashboard', 'email'])
        elif severity == AlertSeverity.CRITICAL:
            channels.extend(['dashboard', 'email', 'webhook'])
        elif severity == AlertSeverity.EMERGENCY:
            channels.extend(['dashboard', 'email', 'webhook', 'sms'])
        
        return channels
```

### 2.4 Continuous Monitoring Tasks

```python
class ContinuousMonitor:
    """Handles continuous monitoring of specific metrics"""
    
    async def monitor_apy_stability(self, strategy_id: str):
        """
        Monitor APY stability over time
        Implements 7-day monitoring from rebalancing rules
        """
        stability_window = timedelta(days=7)
        check_interval = timedelta(hours=1)
        
        while True:
            # Get APY history
            history = await self._get_apy_history(
                strategy_id, 
                since=datetime.utcnow() - stability_window
            )
            
            if not history:
                await asyncio.sleep(check_interval.total_seconds())
                continue
            
            # Check if consistently below base rate
            base_rate = self.config['base_market_rate']
            below_base_count = sum(1 for h in history if h.value < base_rate)
            
            if below_base_count / len(history) > 0.9:  # 90% of time below base
                # Trigger rebalancing consideration
                await self._create_alert(
                    rule_name="APY_CONSISTENTLY_LOW",
                    strategy_id=strategy_id,
                    severity=AlertSeverity.WARNING,
                    message=f"APY consistently below base rate for {stability_window.days} days"
                )
            
            await asyncio.sleep(check_interval.total_seconds())
    
    async def monitor_tvl_trends(self, strategy_id: str):
        """Monitor TVL trends for sharp changes"""
        while True:
            current_tvl = await self._get_current_tvl(strategy_id)
            
            # Store in rolling window
            await self._update_rolling_window(f"tvl:{strategy_id}", current_tvl)
            
            # Check for sharp drops
            window = await self._get_rolling_window(f"tvl:{strategy_id}")
            
            if len(window) >= 2:
                # Check 1-hour change
                one_hour_ago = window[-60] if len(window) >= 60 else window[0]
                change_1h = (current_tvl - one_hour_ago) / one_hour_ago
                
                if change_1h < -0.1:  # -10% in 1 hour
                    await self._create_alert(
                        rule_name="TVL_SHARP_DROP",
                        strategy_id=strategy_id,
                        severity=AlertSeverity.CRITICAL,
                        message=f"TVL dropped {abs(change_1h)*100:.1f}% in 1 hour"
                    )
            
            await asyncio.sleep(60)  # Check every minute
```

### 2.5 WebSocket Streaming

```python
class WebSocketStreamer:
    """Handles real-time streaming to connected clients"""
    
    def __init__(self):
        self.clients = set()
        self.subscriptions = {}  # client_id -> set of strategy_ids
        
    async def handle_client(self, websocket, path):
        """Handle WebSocket client connection"""
        client_id = str(uuid.uuid4())
        self.clients.add((client_id, websocket))
        
        try:
            async for message in websocket:
                data = json.loads(message)
                
                if data['type'] == 'subscribe':
                    await self._handle_subscribe(client_id, data['strategies'])
                elif data['type'] == 'unsubscribe':
                    await self._handle_unsubscribe(client_id, data['strategies'])
                elif data['type'] == 'ping':
                    await websocket.send(json.dumps({'type': 'pong'}))
                    
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.clients.remove((client_id, websocket))
            del self.subscriptions[client_id]
    
    async def broadcast_update(self, strategy_id: str, update: Dict):
        """Broadcast update to subscribed clients"""
        message = json.dumps({
            'type': 'update',
            'strategy_id': strategy_id,
            'timestamp': datetime.utcnow().isoformat(),
            'data': update
        })
        
        # Send to all subscribed clients
        for client_id, websocket in self.clients:
            if strategy_id in self.subscriptions.get(client_id, set()):
                try:
                    await websocket.send(message)
                except:
                    # Client disconnected
                    pass
    
    async def broadcast_alert(self, alert: Alert):
        """Broadcast alert to all clients"""
        message = json.dumps({
            'type': 'alert',
            'severity': alert.severity.value,
            'timestamp': alert.timestamp.isoformat(),
            'data': {
                'rule': alert.rule_name,
                'strategy_id': alert.strategy_id,
                'message': alert.message,
                'value': alert.metric_value,
                'threshold': alert.threshold
            }
        })
        
        # Send to all connected clients
        for _, websocket in self.clients:
            try:
                await websocket.send(message)
            except:
                pass
```

---

## 3. Technical Specifications

### 3.1 API Endpoints

```yaml
# Monitoring Status
GET /api/v1/monitoring/status:
  description: Get monitoring service status
  response:
    active_monitors: int
    total_alerts_24h: int
    active_positions: int
    last_check: timestamp

# Alerts
GET /api/v1/alerts:
  description: Get recent alerts
  query:
    severity?: string
    strategy_id?: string
    limit?: int
    since?: timestamp
  response:
    alerts: array

POST /api/v1/alerts/acknowledge/{id}:
  description: Acknowledge an alert
  response:
    status: string

# Metrics
GET /api/v1/metrics/{strategy_id}:
  description: Get current metrics for strategy
  response:
    metrics: object

GET /api/v1/metrics/{strategy_id}/history:
  description: Get historical metrics
  query:
    metric: string
    start: timestamp
    end: timestamp
  response:
    data_points: array

# WebSocket
WS /ws:
  description: WebSocket for real-time updates
  messages:
    subscribe: {"type": "subscribe", "strategies": ["id1", "id2"]}
    update: {"type": "update", "strategy_id": "...", "data": {...}}
    alert: {"type": "alert", "severity": "...", "data": {...}}

# Health Checks
GET /api/v1/monitoring/health/{strategy_id}:
  description: Get health assessment for strategy
  response:
    health_score: number
    risk_factors: array
    recommendations: array
```

### 3.2 Database Schema

```sql
-- Alerts table
CREATE TABLE alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    rule_name VARCHAR(100) NOT NULL,
    position_id UUID,
    strategy_id VARCHAR(200) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    metric_name VARCHAR(100),
    metric_value DECIMAL(20,8),
    threshold DECIMAL(20,8),
    message TEXT,
    auto_action BOOLEAN DEFAULT FALSE,
    action_type VARCHAR(50),
    action_executed BOOLEAN DEFAULT FALSE,
    acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_by VARCHAR(100),
    acknowledged_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_strategy (strategy_id),
    INDEX idx_severity (severity),
    INDEX idx_created (created_at DESC)
);

-- Metrics time-series (using TimescaleDB)
CREATE TABLE metrics (
    time TIMESTAMPTZ NOT NULL,
    strategy_id VARCHAR(200) NOT NULL,
    tvl DECIMAL(20,2),
    apy DECIMAL(10,4),
    liquidity DECIMAL(20,2),
    health_factor DECIMAL(5,2),
    risk_score DECIMAL(5,2),
    gas_price DECIMAL(10,2),
    metadata JSONB
);

SELECT create_hypertable('metrics', 'time');
CREATE INDEX idx_metrics_strategy ON metrics (strategy_id, time DESC);

-- Monitoring rules configuration
CREATE TABLE monitoring_rules (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    metric VARCHAR(100) NOT NULL,
    threshold DECIMAL(20,8),
    comparison VARCHAR(20),
    severity VARCHAR(20),
    cooldown_seconds INT DEFAULT 300,
    auto_action BOOLEAN DEFAULT FALSE,
    action_type VARCHAR(50),
    enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Alert cooldowns (prevent spam)
CREATE TABLE alert_cooldowns (
    position_id UUID,
    rule_name VARCHAR(100),
    last_triggered TIMESTAMP,
    PRIMARY KEY (position_id, rule_name)
);
```

### 3.3 Configuration

```yaml
# monitoring-config.yaml
service:
  name: monitoring
  port: 8084
  workers: 4
  
monitoring:
  check_interval: 60  # seconds
  
  # Thresholds from rebalancing rules
  tvl_drop_threshold: 0.10          # 10% drop
  apy_decline_days: 7               # Days below base rate
  liquidity_crisis_threshold: 0.50  # 50% drop
  health_factor_warning: 1.5
  
  # Market parameters
  base_market_rate: 0.045  # 4.5%
  
  # Alert settings
  alert_cooldown_default: 300  # 5 minutes
  max_alerts_per_hour: 100
  
websocket:
  enabled: true
  port: 8084
  ping_interval: 30
  
notifications:
  email:
    enabled: true
    smtp_host: ${SMTP_HOST}
    smtp_port: 587
    from_address: alerts@defi-system.com
    
  webhook:
    enabled: true
    url: ${WEBHOOK_URL}
    timeout: 10
    
  sms:
    enabled: false
    provider: twilio
    
monitoring_rules:
  - name: TVL_DROP
    metric: tvl_change_1h
    threshold: -0.10
    comparison: lt
    severity: CRITICAL
    
  - name: APY_DEGRADATION
    metric: apy_vs_base_rate
    threshold: 1.0
    comparison: lt
    severity: WARNING
    
  - name: LIQUIDITY_CRISIS
    metric: liquidity_change_24h
    threshold: -0.50
    comparison: lt
    severity: EMERGENCY
```

---

## 4. Docker Configuration

```dockerfile
# Dockerfile for Monitoring Service
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Create non-root user
RUN useradd -m -u 1000 monitor && \
    chown -R monitor:monitor /app

USER monitor

EXPOSE 8084

HEALTHCHECK --interval=30s --timeout=5s \
  CMD python -c "import requests; requests.get('http://localhost:8084/health')" || exit 1

CMD ["python", "-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8084"]
```

### requirements.txt
```
fastapi==0.104.1
uvicorn[standard]==0.24.0
websockets==12.0
aiohttp==3.9.0
asyncpg==0.29.0
aioredis==2.0.1
pydantic==2.5.0
prometheus-client==0.19.0
python-dotenv==1.0.0
numpy==1.26.2
pandas==2.1.3
```

### Docker Compose Service
```yaml
monitoring:
  build:
    context: ./services/monitoring
    dockerfile: Dockerfile
  container_name: defi-monitoring
  environment:
    - SERVICE_NAME=monitoring
    - PORT=8084
    - LOG_LEVEL=${LOG_LEVEL:-info}
    - DATABASE_URL=postgres://defi:${DB_PASSWORD}@postgres:5432/defi_portfolio
    - REDIS_URL=redis://redis:6379/3
    - TVL_DROP_THRESHOLD=0.10
    - APY_DECLINE_DAYS=7
    - LIQUIDITY_CRISIS_THRESHOLD=0.5
    - HEALTH_FACTOR_WARNING=1.5
    - ALERT_COOLDOWN=300
    - CHECK_INTERVAL=60
    - WEBSOCKET_ENABLED=true
    - WEBHOOK_URL=${ALERT_WEBHOOK_URL}
    - BASE_MARKET_RATE=0.045
  depends_on:
    postgres:
      condition: service_healthy
    redis:
      condition: service_healthy
    data-aggregator:
      condition: service_healthy
  volumes:
    - ./services/monitoring/config:/app/config:ro
  ports:
    - "8084:8084"
    - "9094:9094"  # Metrics
  networks:
    - defi-network
  restart: unless-stopped
  deploy:
    replicas: 2
    resources:
      limits:
        memory: 1G
        cpus: '1.0'
      reservations:
        memory: 512M
        cpus: '0.5'
```

---

## 5. Implementation Guidelines

### 5.1 Code Structure

```
monitoring/
├── app/
│   ├── main.py
│   ├── api/
│   │   ├── routes.py
│   │   └── websocket.py
│   ├── core/
│   │   ├── engine.py
│   │   ├── rules.py
│   │   └── alerts.py
│   ├── monitors/
│   │   ├── tvl.py
│   │   ├── apy.py
│   │   ├── liquidity.py
│   │   └── health.py
│   ├── processors/
│   │   ├── alert.py
│   │   └── notification.py
│   ├── models/
│   │   └── metrics.py
│   └── utils/
│       └── calculations.py
├── tests/
├── config/
├── requirements.txt
└── Dockerfile
```

### 5.2 Testing Requirements

```python
# Test alert generation
async def test_alert_generation():
    monitor = MonitoringEngine(test_config)
    
    # Simulate TVL drop
    metrics = {
        'tvl': 45_000_000,
        'tvl_change_1h': -0.15,  # -15%
    }
    
    alerts = await monitor._check_rules(test_position, metrics)
    assert len(alerts) > 0
    assert alerts[0].severity == AlertSeverity.CRITICAL
```

---

## 6. Performance Requirements

- Monitoring latency: <1 second for critical metrics
- Alert generation: <500ms from detection
- WebSocket latency: <100ms
- Concurrent monitors: 100+ strategies
- Memory usage: <500MB per instance

---

## 7. Monitoring & Observability

### Metrics
```yaml
Monitoring Metrics:
  - monitors_active (gauge)
  - alerts_generated_total (counter, by: severity, rule)
  - alert_response_time_seconds (histogram)
  - websocket_connections (gauge)
  - metrics_collected_total (counter, by: type)
  
System Metrics:
  - check_duration_seconds (histogram)
  - notification_sent_total (counter, by: channel)
  - rule_evaluation_duration (histogram)
```

---

**END OF MONITORING SERVICE PRD**
